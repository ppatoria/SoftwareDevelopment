<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=us-ascii" />
<title>boost/detail/limits.hpp - 1.54.0</title>  <link rel="icon" href="/favicon.ico" type="image/ico" />
  <link rel="stylesheet" type="text/css" href="/style-v2/section-doc.css" />
  <!--[if IE 7]> <style type="text/css"> body { behavior: url(/style-v2/csshover3.htc); } </style> <![endif]-->

</head>

<body>
  <div id="heading">
    <div class="heading-inner">
  <div class="heading-placard"></div>

  <h1 class="heading-title">
  <a href="/">
  <img src="/gfx/space.png" alt= "Boost C++ Libraries" class="heading-logo" />
  <span class="heading-boost">Boost</span>
  <span class="heading-cpplibraries">C++ Libraries</span>
  </a></h1>

  <p class="heading-quote">
  <q>...one of the most highly
  regarded and expertly designed C++ library projects in the
  world.</q> <span class="heading-attribution">&mdash; <a href=
  "http://www.gotw.ca/" class="external">Herb Sutter</a> and <a href=
  "http://en.wikipedia.org/wiki/Andrei_Alexandrescu" class="external">Andrei
  Alexandrescu</a>, <a href=
  "http://safari.awprofessional.com/?XmlId=0321113586" class="external">C++
  Coding Standards</a></span></p>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33761719-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
  </div>

  <div id="body">
    <div id="body-inner">
      <div id="content">
        <div class="section" id="docs">
          <div class="section-0">
            <div class="section-body">
              <h3>boost/detail/limits.hpp</h3>
<pre>
// Copyright 2001 John Maddock
// Distributed under the Boost Software License, Version 1.0. (See accompany-
// ing file LICENSE_1_0.txt or copy at <a href="http://www.boost.org/LICENSE_1_0.txt">http://www.boost.org/LICENSE_1_0.txt</a>)

/*
 * Copyright (c) 1997
 * Silicon Graphics Computer Systems, Inc.
 *
 * Permission to use, copy, modify, distribute and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear
 * in supporting documentation.  Silicon Graphics makes no
 * representations about the suitability of this software for any
 * purpose.  It is provided &quot;as is&quot; without express or implied warranty.
 */

/* NOTE: This is not portable code.  Parts of numeric_limits&lt;&gt; are
 * inherently machine-dependent, and this file is written for the MIPS
 * architecture and the SGI MIPSpro C++ compiler.  Parts of it (in
 * particular, some of the characteristics of floating-point types)
 * are almost certainly incorrect for any other platform.
 */

/* The above comment is almost certainly out of date. This file works
 * on systems other than SGI MIPSpro C++ now.
 */

/*
 * Revision history:
 * 21 Sep 2001:
 *    Only include &lt;cwchar&gt; if BOOST_NO_CWCHAR is defined. (Darin Adler)
 * 10 Aug 2001:
 *    Added MIPS (big endian) to the big endian family. (Jens Maurer)
 * 13 Apr 2001:
 *    Added powerpc to the big endian family. (Jeremy Siek)
 * 5 Apr 2001:
 *    Added sparc (big endian) processor support (John Maddock).
 * Initial sub:
 *      Modified by Jens Maurer for gcc 2.95 on x86.
 */

#ifndef BOOST_SGI_CPP_LIMITS
#define BOOST_SGI_CPP_LIMITS

#include &lt;climits&gt;
#include &lt;cfloat&gt;
#include &lt;<a href="../../boost/config.hpp">boost/config.hpp</a>&gt;
#include &lt;<a href="../../boost/detail/endian.hpp">boost/detail/endian.hpp</a>&gt;

#ifndef BOOST_NO_CWCHAR
#include &lt;cwchar&gt; // for WCHAR_MIN and WCHAR_MAX
#endif

namespace std {

enum float_round_style {
  round_indeterminate       = -1,
  round_toward_zero         =  0,
  round_to_nearest          =  1,
  round_toward_infinity     =  2,
  round_toward_neg_infinity =  3
};

enum float_denorm_style {
  denorm_indeterminate = -1,
  denorm_absent        =  0,
  denorm_present       =  1
};

// The C++ standard (section 18.2.1) requires that some of the members of
// numeric_limits be static const data members that are given constant-
// initializers within the class declaration.  On compilers where the
// BOOST_NO_INCLASS_MEMBER_INITIALIZATION macro is defined, it is impossible to write
// a standard-conforming numeric_limits class.
//
// There are two possible workarounds: either initialize the data
// members outside the class, or change them from data members to
// enums.  Neither workaround is satisfactory: the former makes it
// impossible to use the data members in constant-expressions, and the
// latter means they have the wrong type and that it is impossible to
// take their addresses.  We choose the former workaround.

#ifdef BOOST_NO_INCLASS_MEMBER_INITIALIZATION
# define BOOST_STL_DECLARE_LIMITS_MEMBER(__mem_type, __mem_name, __mem_value) \
  enum { __mem_name = __mem_value }
#else /* BOOST_NO_INCLASS_MEMBER_INITIALIZATION */
# define BOOST_STL_DECLARE_LIMITS_MEMBER(__mem_type, __mem_name, __mem_value) \
  static const __mem_type __mem_name = __mem_value
#endif /* BOOST_NO_INCLASS_MEMBER_INITIALIZATION */

// Base class for all specializations of numeric_limits.
template &lt;class __number&gt;
class _Numeric_limits_base {
public:
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_specialized, false);

  static __number min BOOST_PREVENT_MACRO_SUBSTITUTION () throw() { return __number(); }
  static __number max BOOST_PREVENT_MACRO_SUBSTITUTION () throw() { return __number(); }

  BOOST_STL_DECLARE_LIMITS_MEMBER(int, digits,   0);
  BOOST_STL_DECLARE_LIMITS_MEMBER(int, digits10, 0);

  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_signed,  false);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_integer, false);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_exact,   false);

  BOOST_STL_DECLARE_LIMITS_MEMBER(int, radix, 0);

  static __number epsilon() throw()     { return __number(); }
  static __number round_error() throw() { return __number(); }

  BOOST_STL_DECLARE_LIMITS_MEMBER(int, min_exponent,   0);
  BOOST_STL_DECLARE_LIMITS_MEMBER(int, min_exponent10, 0);
  BOOST_STL_DECLARE_LIMITS_MEMBER(int, max_exponent,   0);
  BOOST_STL_DECLARE_LIMITS_MEMBER(int, max_exponent10, 0);

  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, has_infinity,      false);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, has_quiet_NaN,     false);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, has_signaling_NaN, false);
  BOOST_STL_DECLARE_LIMITS_MEMBER(float_denorm_style,
                              has_denorm,
                              denorm_absent);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, has_denorm_loss,   false);

  static __number infinity() throw()      { return __number(); }
  static __number quiet_NaN() throw()     { return __number(); }
  static __number signaling_NaN() throw() { return __number(); }
  static __number denorm_min() throw()    { return __number(); }

  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_iec559,  false);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_bounded, false);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_modulo,  false);

  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, traps,            false);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, tinyness_before,  false);
  BOOST_STL_DECLARE_LIMITS_MEMBER(float_round_style,
                              round_style,
                              round_toward_zero);
};

// Base class for integers.

template &lt;class _Int,
          _Int __imin,
          _Int __imax,
          int __idigits = -1&gt;
class _Integer_limits : public _Numeric_limits_base&lt;_Int&gt; 
{
public:
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_specialized, true);

  static _Int min BOOST_PREVENT_MACRO_SUBSTITUTION () throw() { return __imin; }
  static _Int max BOOST_PREVENT_MACRO_SUBSTITUTION () throw() { return __imax; }

  BOOST_STL_DECLARE_LIMITS_MEMBER(int,
                              digits,
                              (__idigits &lt; 0) ? (int)(sizeof(_Int) * CHAR_BIT)
                                                   - (__imin == 0 ? 0 : 1) 
                                              : __idigits);
  BOOST_STL_DECLARE_LIMITS_MEMBER(int, digits10, (digits * 301) / 1000); 
                                // log 2 = 0.301029995664...

  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_signed,  __imin != 0);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_integer, true);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_exact,   true);
  BOOST_STL_DECLARE_LIMITS_MEMBER(int,  radix,      2);

  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_bounded, true);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_modulo, true);
};

#if defined(BOOST_BIG_ENDIAN)

 template&lt;class Number, unsigned int Word&gt;
 struct float_helper{
  static Number get_word() throw() {
    // sizeof(long double) == 16
    const unsigned int _S_word[4] = { Word, 0, 0, 0 };
    return *reinterpret_cast&lt;const Number*&gt;(&amp;_S_word);
  } 
};

#else

 template&lt;class Number, unsigned int Word&gt;
 struct float_helper{
  static Number get_word() throw() {
    // sizeof(long double) == 12, but only 10 bytes significant
    const unsigned int _S_word[4] = { 0, 0, 0, Word };
    return *reinterpret_cast&lt;const Number*&gt;(
        reinterpret_cast&lt;const char *&gt;(&amp;_S_word)+16-
                (sizeof(Number) == 12 ? 10 : sizeof(Number)));
  } 
};

#endif

// Base class for floating-point numbers.
template &lt;class __number,
         int __Digits, int __Digits10,
         int __MinExp, int __MaxExp,
         int __MinExp10, int __MaxExp10,
         unsigned int __InfinityWord,
         unsigned int __QNaNWord, unsigned int __SNaNWord,
         bool __IsIEC559,
         float_round_style __RoundStyle&gt;
class _Floating_limits : public _Numeric_limits_base&lt;__number&gt;
{
public:
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_specialized, true);

  BOOST_STL_DECLARE_LIMITS_MEMBER(int, digits,   __Digits);
  BOOST_STL_DECLARE_LIMITS_MEMBER(int, digits10, __Digits10);

  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_signed, true);

  BOOST_STL_DECLARE_LIMITS_MEMBER(int, radix, 2);

  BOOST_STL_DECLARE_LIMITS_MEMBER(int, min_exponent,   __MinExp);
  BOOST_STL_DECLARE_LIMITS_MEMBER(int, max_exponent,   __MaxExp);
  BOOST_STL_DECLARE_LIMITS_MEMBER(int, min_exponent10, __MinExp10);
  BOOST_STL_DECLARE_LIMITS_MEMBER(int, max_exponent10, __MaxExp10);

  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, has_infinity,      true);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, has_quiet_NaN,     true);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, has_signaling_NaN, true);
  BOOST_STL_DECLARE_LIMITS_MEMBER(float_denorm_style,
                              has_denorm,
                              denorm_indeterminate);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, has_denorm_loss,   false);

 
  static __number infinity() throw() {
    return float_helper&lt;__number, __InfinityWord&gt;::get_word();
  }
  static __number quiet_NaN() throw() {
    return float_helper&lt;__number,__QNaNWord&gt;::get_word();
  }
  static __number signaling_NaN() throw() {
    return float_helper&lt;__number,__SNaNWord&gt;::get_word();
  }

  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_iec559,       __IsIEC559);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, is_bounded,      true);
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, traps,           false /* was: true */ );
  BOOST_STL_DECLARE_LIMITS_MEMBER(bool, tinyness_before, false);

  BOOST_STL_DECLARE_LIMITS_MEMBER(float_round_style, round_style, __RoundStyle);
};

// Class numeric_limits

// The unspecialized class.

template&lt;class T&gt; 
class numeric_limits : public _Numeric_limits_base&lt;T&gt; {};

// Specializations for all built-in integral types.

template&lt;&gt;
class numeric_limits&lt;bool&gt;
  : public _Integer_limits&lt;bool, false, true, 0&gt;
{};

template&lt;&gt;
class numeric_limits&lt;char&gt;
  : public _Integer_limits&lt;char, CHAR_MIN, CHAR_MAX&gt;
{};

template&lt;&gt;
class numeric_limits&lt;signed char&gt;
  : public _Integer_limits&lt;signed char, SCHAR_MIN, SCHAR_MAX&gt;
{};

template&lt;&gt;
class numeric_limits&lt;unsigned char&gt;
  : public _Integer_limits&lt;unsigned char, 0, UCHAR_MAX&gt;
{};

#ifndef BOOST_NO_INTRINSIC_WCHAR_T
template&lt;&gt;
class numeric_limits&lt;wchar_t&gt;
#if !defined(WCHAR_MAX) || !defined(WCHAR_MIN)
#if defined(_WIN32) || defined(__CYGWIN__)
  : public _Integer_limits&lt;wchar_t, 0, USHRT_MAX&gt;
#elif defined(__hppa)
// wchar_t has &quot;unsigned int&quot; as the underlying type
  : public _Integer_limits&lt;wchar_t, 0, UINT_MAX&gt;
#else
// assume that wchar_t has &quot;int&quot; as the underlying type
  : public _Integer_limits&lt;wchar_t, INT_MIN, INT_MAX&gt;
#endif
#else
// we have WCHAR_MIN and WCHAR_MAX defined, so use it
  : public _Integer_limits&lt;wchar_t, WCHAR_MIN, WCHAR_MAX&gt;
#endif
{};
#endif

template&lt;&gt;
class numeric_limits&lt;short&gt;
  : public _Integer_limits&lt;short, SHRT_MIN, SHRT_MAX&gt;
{};

template&lt;&gt;
class numeric_limits&lt;unsigned short&gt;
  : public _Integer_limits&lt;unsigned short, 0, USHRT_MAX&gt;
{};

template&lt;&gt;
class numeric_limits&lt;int&gt;
  : public _Integer_limits&lt;int, INT_MIN, INT_MAX&gt;
{};

template&lt;&gt;
class numeric_limits&lt;unsigned int&gt;
  : public _Integer_limits&lt;unsigned int, 0, UINT_MAX&gt;
{};

template&lt;&gt;
class numeric_limits&lt;long&gt;
  : public _Integer_limits&lt;long, LONG_MIN, LONG_MAX&gt;
{};

template&lt;&gt;
class numeric_limits&lt;unsigned long&gt;
  : public _Integer_limits&lt;unsigned long, 0, ULONG_MAX&gt;
{};

#ifdef __GNUC__

// Some compilers have long long, but don't define the
// LONGLONG_MIN and LONGLONG_MAX macros in limits.h.  This
// assumes that long long is 64 bits.
#if !defined(LONGLONG_MAX) &amp;&amp; !defined(ULONGLONG_MAX)

# define ULONGLONG_MAX 0xffffffffffffffffLLU
# define LONGLONG_MAX 0x7fffffffffffffffLL

#endif

#if !defined(LONGLONG_MIN)
# define LONGLONG_MIN (-LONGLONG_MAX - 1)
#endif 


#if !defined(ULONGLONG_MIN)
# define ULONGLONG_MIN 0
#endif 

#endif /* __GNUC__ */

// Specializations for all built-in floating-point type.

template&lt;&gt; class numeric_limits&lt;float&gt;
  : public _Floating_limits&lt;float, 
                            FLT_MANT_DIG,   // Binary digits of precision
                            FLT_DIG,        // Decimal digits of precision
                            FLT_MIN_EXP,    // Minimum exponent
                            FLT_MAX_EXP,    // Maximum exponent
                            FLT_MIN_10_EXP, // Minimum base 10 exponent
                            FLT_MAX_10_EXP, // Maximum base 10 exponent
#if defined(BOOST_BIG_ENDIAN)
                            0x7f80 &lt;&lt; (sizeof(int)*CHAR_BIT-16),    // Last word of +infinity
                            0x7f81 &lt;&lt; (sizeof(int)*CHAR_BIT-16),    // Last word of quiet NaN
                            0x7fc1 &lt;&lt; (sizeof(int)*CHAR_BIT-16),    // Last word of signaling NaN
#else
                            0x7f800000u,    // Last word of +infinity
                            0x7f810000u,    // Last word of quiet NaN
                            0x7fc10000u,    // Last word of signaling NaN
#endif
                            true,           // conforms to iec559
                            round_to_nearest&gt;
{
public:
  static float min BOOST_PREVENT_MACRO_SUBSTITUTION () throw() { return FLT_MIN; }
  static float denorm_min() throw() { return FLT_MIN; }
  static float max BOOST_PREVENT_MACRO_SUBSTITUTION () throw() { return FLT_MAX; }
  static float epsilon() throw() { return FLT_EPSILON; }
  static float round_error() throw() { return 0.5f; } // Units: ulps.
};

template&lt;&gt; class numeric_limits&lt;double&gt;
  : public _Floating_limits&lt;double, 
                            DBL_MANT_DIG,   // Binary digits of precision
                            DBL_DIG,        // Decimal digits of precision
                            DBL_MIN_EXP,    // Minimum exponent
                            DBL_MAX_EXP,    // Maximum exponent
                            DBL_MIN_10_EXP, // Minimum base 10 exponent
                            DBL_MAX_10_EXP, // Maximum base 10 exponent
#if defined(BOOST_BIG_ENDIAN)
                            0x7ff0 &lt;&lt; (sizeof(int)*CHAR_BIT-16),    // Last word of +infinity
                            0x7ff1 &lt;&lt; (sizeof(int)*CHAR_BIT-16),    // Last word of quiet NaN
                            0x7ff9 &lt;&lt; (sizeof(int)*CHAR_BIT-16),    // Last word of signaling NaN
#else
                            0x7ff00000u,    // Last word of +infinity
                            0x7ff10000u,    // Last word of quiet NaN
                            0x7ff90000u,    // Last word of signaling NaN
#endif
                            true,           // conforms to iec559
                            round_to_nearest&gt;
{
public:
  static double min BOOST_PREVENT_MACRO_SUBSTITUTION () throw() { return DBL_MIN; }
  static double denorm_min() throw() { return DBL_MIN; }
  static double max BOOST_PREVENT_MACRO_SUBSTITUTION () throw() { return DBL_MAX; }
  static double epsilon() throw() { return DBL_EPSILON; }
  static double round_error() throw() { return 0.5; } // Units: ulps.
};

template&lt;&gt; class numeric_limits&lt;long double&gt;
  : public _Floating_limits&lt;long double, 
                            LDBL_MANT_DIG,  // Binary digits of precision
                            LDBL_DIG,       // Decimal digits of precision
                            LDBL_MIN_EXP,   // Minimum exponent
                            LDBL_MAX_EXP,   // Maximum exponent
                            LDBL_MIN_10_EXP,// Minimum base 10 exponent
                            LDBL_MAX_10_EXP,// Maximum base 10 exponent
#if defined(BOOST_BIG_ENDIAN)
                            0x7ff0 &lt;&lt; (sizeof(int)*CHAR_BIT-16),    // Last word of +infinity
                            0x7ff1 &lt;&lt; (sizeof(int)*CHAR_BIT-16),    // Last word of quiet NaN
                            0x7ff9 &lt;&lt; (sizeof(int)*CHAR_BIT-16),    // Last word of signaling NaN
#else
                            0x7fff8000u,    // Last word of +infinity
                            0x7fffc000u,    // Last word of quiet NaN
                            0x7fff9000u,    // Last word of signaling NaN
#endif
                            false,          // Doesn't conform to iec559
                            round_to_nearest&gt;
{
public:
  static long double min BOOST_PREVENT_MACRO_SUBSTITUTION () throw() { return LDBL_MIN; }
  static long double denorm_min() throw() { return LDBL_MIN; }
  static long double max BOOST_PREVENT_MACRO_SUBSTITUTION () throw() { return LDBL_MAX; }
  static long double epsilon() throw() { return LDBL_EPSILON; }
  static long double round_error() throw() { return 4; } // Units: ulps.
};

} // namespace std

#endif /* BOOST_SGI_CPP_LIMITS */

// Local Variables:
// mode:C++
// End:



</pre>
            </div>
          </div>
        </div>
      </div>

      <div class="clear"></div>
    </div>
  </div>

  <div id="footer">
    <div id="footer-left">
      <div id="revised">
        <p>Revised $Date: 2010-09-26 09:11:52 -0400 (Sun, 26 Sep 2010) $</p>
      </div>

      <div id="copyright">
        <p>Copyright Beman Dawes, David Abrahams, 1998-2005.</p>

        <p>Copyright Rene Rivera 2004-2008.</p>
      </div>  <div id="license">
    <p>Distributed under the <a href="/LICENSE_1_0.txt" class=
    "internal">Boost Software License, Version 1.0</a>.</p>
  </div>
    </div>

    <div id="footer-right">
        <div id="banners">
    <p id="banner-xhtml"><a href="http://validator.w3.org/check?uri=referer"
    class="external">XHTML 1.0</a></p>

    <p id="banner-css"><a href=
    "http://jigsaw.w3.org/css-validator/check/referer" class=
    "external">CSS</a></p>

    <p id="banner-osi"><a href=
    "http://www.opensource.org/docs/definition.php" class="external">OSI
    Certified</a></p>
  </div>
    </div>

    <div class="clear"></div>
  </div>
</body>
</html>