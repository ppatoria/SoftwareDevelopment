<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=us-ascii" />
<title>libs/io/test/ios_state_test.cpp - 1.54.0</title>  <link rel="icon" href="/favicon.ico" type="image/ico" />
  <link rel="stylesheet" type="text/css" href="/style-v2/section-doc.css" />
  <!--[if IE 7]> <style type="text/css"> body { behavior: url(/style-v2/csshover3.htc); } </style> <![endif]-->

</head>

<body>
  <div id="heading">
    <div class="heading-inner">
  <div class="heading-placard"></div>

  <h1 class="heading-title">
  <a href="/">
  <img src="/gfx/space.png" alt= "Boost C++ Libraries" class="heading-logo" />
  <span class="heading-boost">Boost</span>
  <span class="heading-cpplibraries">C++ Libraries</span>
  </a></h1>

  <p class="heading-quote">
  <q>...one of the most highly
  regarded and expertly designed C++ library projects in the
  world.</q> <span class="heading-attribution">&mdash; <a href=
  "http://www.gotw.ca/" class="external">Herb Sutter</a> and <a href=
  "http://en.wikipedia.org/wiki/Andrei_Alexandrescu" class="external">Andrei
  Alexandrescu</a>, <a href=
  "http://safari.awprofessional.com/?XmlId=0321113586" class="external">C++
  Coding Standards</a></span></p>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33761719-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
  </div>

  <div id="body">
    <div id="body-inner">
      <div id="content">
        <div class="section" id="docs">
          <div class="section-0">
            <div class="section-body">
              <h3>libs/io/test/ios_state_test.cpp</h3>
<pre>
//  Boost ios_state_test.cpp test file  --------------------------------------//

//  Copyright 2002, 2003 Daryle Walker.  Use, modification, and distribution are
//  subject to the Boost Software License, Version 1.0.  (See accompanying file
//  LICENSE_1_0.txt or a copy at &lt;<a href="http://www.boost.org/LICENSE_1_0.txt">http://www.boost.org/LICENSE_1_0.txt</a>&gt;.)

//  See &lt;<a href="http://www.boost.org/libs/io/">http://www.boost.org/libs/io/</a>&gt; for the library's home page.

//  Revision History
//   15 Jun 2003  Adjust to changes in Boost.Test (Daryle Walker)
//   26 Feb 2002  Initial version (Daryle Walker)

#include &lt;<a href="../../../boost/test/minimal.hpp">boost/test/minimal.hpp</a>&gt;  // main, BOOST_CHECK, etc.

#include &lt;<a href="../../../boost/cstdlib.hpp">boost/cstdlib.hpp</a>&gt;       // for boost::exit_success
#include &lt;<a href="../../../boost/io/ios_state.hpp">boost/io/ios_state.hpp</a>&gt;  // for boost::io::ios_flags_saver, etc.

#include &lt;cstddef&gt;    // for std::size_t
#include &lt;iomanip&gt;    // for std::setw
#include &lt;ios&gt;        // for std::ios_base, std::streamsize, etc.
#include &lt;iostream&gt;   // for std::cout, etc.
#include &lt;istream&gt;    // for std::istream
#include &lt;locale&gt;     // for std::numpunct, std::locale
#include &lt;ostream&gt;    // for std::endl, std::ostream
#include &lt;streambuf&gt;  // for std::streambuf
#include &lt;string&gt;     // for std::string


// Facet with the bool names spelled backwards
class backward_bool_names
    : public std::numpunct&lt;char&gt;
{
    typedef std::numpunct&lt;char&gt;  base_type;

public:
    explicit  backward_bool_names( std::size_t refs = 0 )
        : base_type( refs )
        {}

protected:
    virtual ~backward_bool_names() {}

    virtual  base_type::string_type  do_truename() const
        { return &quot;eurt&quot;; }
    virtual  base_type::string_type  do_falsename() const
        { return &quot;eslaf&quot;; }
};


// Index to test custom storage
int const  my_index = std::ios_base::xalloc();

// Test data
char const    test_string[] = &quot;Hello world&quot;;
int const     test_num1 = -16;
double const  test_num2 = 34.5678901234;
bool const    test_bool = true;


// Function prototypes
void  saver_tests_1( std::istream &amp;input, std::ostream &amp;output,
 std::ostream &amp;err );
void  saver_tests_2( std::istream &amp;input, std::ostream &amp;output,
 std::ostream &amp;err );


// Test program
int
test_main
(
    int         ,   // &quot;argc&quot; is unused
    char *      []  // &quot;argv&quot; is unused
)
{
    using std::cout;
    using std::ios_base;
    using std::streamsize;
    using std::cin;

    cout &lt;&lt; &quot;The original data is:\n&quot;;
    cout &lt;&lt; '\t' &lt;&lt; test_string &lt;&lt; '\n';
    cout &lt;&lt; '\t' &lt;&lt; test_num1 &lt;&lt; '\n';
    cout &lt;&lt; '\t' &lt;&lt; test_num2 &lt;&lt; '\n';
    cout &lt;&lt; '\t' &lt;&lt; std::boolalpha &lt;&lt; test_bool &lt;&lt; std::endl;

    // Save states for comparison later
    ios_base::fmtflags const  cout_flags = cout.flags();
    streamsize const          cout_precision = cout.precision();
    streamsize const          cout_width = cout.width();
    ios_base::iostate const   cout_iostate = cout.rdstate();
    ios_base::iostate const   cout_exceptions = cout.exceptions();
    std::ostream * const      cin_tie = cin.tie();
    std::streambuf * const    cout_sb = cout.rdbuf();
    char const                cout_fill = cout.fill();
    std::locale const         cout_locale = cout.getloc();

    cout.iword( my_index ) = 42L;
    cout.pword( my_index ) = &amp;cin;

    // Run saver tests with changing separate from saving
    saver_tests_1( cin, cout, std::cerr );

    // Check if states are back to normal
    BOOST_CHECK( &amp;cin == cout.pword(my_index) );
    BOOST_CHECK( 42L == cout.iword(my_index) );
    BOOST_CHECK( cout_locale == cout.getloc() );
    BOOST_CHECK( cout_fill == cout.fill() );
    BOOST_CHECK( cout_sb == cout.rdbuf() );
    BOOST_CHECK( cin_tie == cin.tie() );
    BOOST_CHECK( cout_exceptions == cout.exceptions() );
    BOOST_CHECK( cout_iostate == cout.rdstate() );
    BOOST_CHECK( cout_width == cout.width() );
    BOOST_CHECK( cout_precision == cout.precision() );
    BOOST_CHECK( cout_flags == cout.flags() );

    // Run saver tests with combined saving and changing
    saver_tests_2( cin, cout, std::cerr );

    // Check if states are back to normal
    BOOST_CHECK( &amp;cin == cout.pword(my_index) );
    BOOST_CHECK( 42L == cout.iword(my_index) );
    BOOST_CHECK( cout_locale == cout.getloc() );
    BOOST_CHECK( cout_fill == cout.fill() );
    BOOST_CHECK( cout_sb == cout.rdbuf() );
    BOOST_CHECK( cin_tie == cin.tie() );
    BOOST_CHECK( cout_exceptions == cout.exceptions() );
    BOOST_CHECK( cout_iostate == cout.rdstate() );
    BOOST_CHECK( cout_width == cout.width() );
    BOOST_CHECK( cout_precision == cout.precision() );
    BOOST_CHECK( cout_flags == cout.flags() );

    return boost::exit_success;
}

// Save, change, and restore stream properties
void
saver_tests_1
(
    std::istream &amp;  input,
    std::ostream &amp;  output,
    std::ostream &amp;  err
)
{
    using std::locale;
    using std::ios_base;
    using std::setw;

    boost::io::ios_flags_saver const      ifls( output );
    boost::io::ios_precision_saver const  iprs( output );
    boost::io::ios_width_saver const      iws( output );
    boost::io::ios_tie_saver const        its( input );
    boost::io::ios_rdbuf_saver const      irs( output );
    boost::io::ios_fill_saver const       ifis( output );
    boost::io::ios_locale_saver const     ils( output );
    boost::io::ios_iword_saver const      iis( output, my_index );
    boost::io::ios_pword_saver const      ipws( output, my_index );

    locale  loc( locale::classic(), new backward_bool_names );

    input.tie( &amp;err );
    output.rdbuf( err.rdbuf() );
    output.iword( my_index ) = 69L;
    output.pword( my_index ) = &amp;err;

    output &lt;&lt; &quot;The data is (again):\n&quot;;
    output.setf( ios_base::showpos | ios_base::boolalpha );
    output.setf( ios_base::internal, ios_base::adjustfield );
    output.fill( '@' );
    output.precision( 9 );
    output &lt;&lt; '\t' &lt;&lt; test_string &lt;&lt; '\n';
    output &lt;&lt; '\t' &lt;&lt; setw( 10 ) &lt;&lt; test_num1 &lt;&lt; '\n';
    output &lt;&lt; '\t' &lt;&lt; setw( 15 ) &lt;&lt; test_num2 &lt;&lt; '\n';
    output.imbue( loc );
    output &lt;&lt; '\t' &lt;&lt; test_bool &lt;&lt; '\n';

    BOOST_CHECK( &amp;err == output.pword(my_index) );
    BOOST_CHECK( 69L == output.iword(my_index) );

    try
    {
        boost::io::ios_exception_saver const  ies( output );
        boost::io::ios_iostate_saver const    iis( output );

        output.exceptions( ios_base::eofbit );
        output.setstate( ios_base::eofbit );
        BOOST_ERROR( &quot;previous line should have thrown&quot; );
    }
    catch ( ios_base::failure &amp;f )
    {
        err &lt;&lt; &quot;Got the expected I/O failure: \&quot;&quot; &lt;&lt; f.what() &lt;&lt; &quot;\&quot;.\n&quot;;
        BOOST_CHECK( output.exceptions() == ios_base::goodbit );
    }
    catch ( ... )
    {
        err &lt;&lt; &quot;Got an unknown error when doing exception test!\n&quot;;
        throw;
    }
}

// Save &amp; change and restore stream properties
void
saver_tests_2
(
    std::istream &amp;  input,
    std::ostream &amp;  output,
    std::ostream &amp;  err
)
{
    using std::locale;
    using std::ios_base;

    boost::io::ios_tie_saver const    its( input, &amp;err );
    boost::io::ios_rdbuf_saver const  irs( output, err.rdbuf() );
    boost::io::ios_iword_saver const  iis( output, my_index, 69L );
    boost::io::ios_pword_saver const  ipws( output, my_index, &amp;err );
    output &lt;&lt; &quot;The data is (a third time; adding the numbers):\n&quot;;

    boost::io::ios_flags_saver const      ifls( output, (output.flags()
     &amp; ~ios_base::adjustfield) | ios_base::showpos | ios_base::boolalpha
     | (ios_base::internal &amp; ios_base::adjustfield) );
    boost::io::ios_precision_saver const  iprs( output, 9 );
    boost::io::ios_fill_saver const       ifis( output, '@' );
    output &lt;&lt; '\t' &lt;&lt; test_string &lt;&lt; '\n';

    boost::io::ios_width_saver const  iws( output, 12 );
    output.put( '\t' );
    output &lt;&lt; test_num1 + test_num2;
    output.put( '\n' );

    locale                             loc( locale::classic(),
     new backward_bool_names );
    boost::io::ios_locale_saver const  ils( output, loc );
    output &lt;&lt; '\t' &lt;&lt; test_bool &lt;&lt; '\n';

    BOOST_CHECK( &amp;err == output.pword(my_index) );
    BOOST_CHECK( 69L == output.iword(my_index) );

    try
    {
        boost::io::ios_exception_saver const  ies( output, ios_base::eofbit  );
        boost::io::ios_iostate_saver const    iis( output, output.rdstate()
         | ios_base::eofbit );

        BOOST_ERROR( &quot;previous line should have thrown&quot; );
    }
    catch ( ios_base::failure &amp;f )
    {
        err &lt;&lt; &quot;Got the expected I/O failure: \&quot;&quot; &lt;&lt; f.what() &lt;&lt; &quot;\&quot;.\n&quot;;
        BOOST_CHECK( output.exceptions() == ios_base::goodbit );
    }
    catch ( ... )
    {
        err &lt;&lt; &quot;Got an unknown error when doing exception test!\n&quot;;
        throw;
    }
}
</pre>
            </div>
          </div>
        </div>
      </div>

      <div class="clear"></div>
    </div>
  </div>

  <div id="footer">
    <div id="footer-left">
      <div id="revised">
        <p>Revised $Date: 2010-09-26 09:11:52 -0400 (Sun, 26 Sep 2010) $</p>
      </div>

      <div id="copyright">
        <p>Copyright Beman Dawes, David Abrahams, 1998-2005.</p>

        <p>Copyright Rene Rivera 2004-2008.</p>
      </div>  <div id="license">
    <p>Distributed under the <a href="/LICENSE_1_0.txt" class=
    "internal">Boost Software License, Version 1.0</a>.</p>
  </div>
    </div>

    <div id="footer-right">
        <div id="banners">
    <p id="banner-xhtml"><a href="http://validator.w3.org/check?uri=referer"
    class="external">XHTML 1.0</a></p>

    <p id="banner-css"><a href=
    "http://jigsaw.w3.org/css-validator/check/referer" class=
    "external">CSS</a></p>

    <p id="banner-osi"><a href=
    "http://www.opensource.org/docs/definition.php" class="external">OSI
    Certified</a></p>
  </div>
    </div>

    <div class="clear"></div>
  </div>
</body>
</html>