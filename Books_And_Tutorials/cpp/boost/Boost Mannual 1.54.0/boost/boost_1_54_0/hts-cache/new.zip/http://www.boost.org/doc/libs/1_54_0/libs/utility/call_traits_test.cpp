<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=us-ascii" />
<title>libs/utility/call_traits_test.cpp - 1.54.0</title>  <link rel="icon" href="/favicon.ico" type="image/ico" />
  <link rel="stylesheet" type="text/css" href="/style-v2/section-doc.css" />
  <!--[if IE 7]> <style type="text/css"> body { behavior: url(/style-v2/csshover3.htc); } </style> <![endif]-->

</head>

<body>
  <div id="heading">
    <div class="heading-inner">
  <div class="heading-placard"></div>

  <h1 class="heading-title">
  <a href="/">
  <img src="/gfx/space.png" alt= "Boost C++ Libraries" class="heading-logo" />
  <span class="heading-boost">Boost</span>
  <span class="heading-cpplibraries">C++ Libraries</span>
  </a></h1>

  <p class="heading-quote">
  <q>...one of the most highly
  regarded and expertly designed C++ library projects in the
  world.</q> <span class="heading-attribution">&mdash; <a href=
  "http://www.gotw.ca/" class="external">Herb Sutter</a> and <a href=
  "http://en.wikipedia.org/wiki/Andrei_Alexandrescu" class="external">Andrei
  Alexandrescu</a>, <a href=
  "http://safari.awprofessional.com/?XmlId=0321113586" class="external">C++
  Coding Standards</a></span></p>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33761719-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
  </div>

  <div id="body">
    <div id="body-inner">
      <div id="content">
        <div class="section" id="docs">
          <div class="section-0">
            <div class="section-body">
              <h3>libs/utility/call_traits_test.cpp</h3>
<pre>
//  boost::compressed_pair test program   
    
//  (C) Copyright John Maddock 2000. 
//  Use, modification and distribution are subject to the Boost Software License,
//  Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  <a href="http://www.boost.org/LICENSE_1_0.txt">http://www.boost.org/LICENSE_1_0.txt</a>).


// standalone test program for &lt;boost/call_traits.hpp&gt;
// 18 Mar 2002:
//    Changed some names to prevent conflicts with some new type_traits additions.
// 03 Oct 2000:
//    Enabled extra tests for VC6.

#include &lt;iostream&gt;
#include &lt;iomanip&gt;
#include &lt;algorithm&gt;
#include &lt;typeinfo&gt;
#include &lt;<a href="../../boost/call_traits.hpp">boost/call_traits.hpp</a>&gt;

#include &lt;libs/type_traits/test/test.hpp&gt;
#include &lt;libs/type_traits/test/check_type.hpp&gt;

#ifdef BOOST_MSVC
#pragma warning(disable:4181) // : warning C4181: qualifier applied to reference type; ignored
#endif

// a way prevent warnings for unused variables
template&lt;class T&gt; inline void unused_variable(const T&amp;) {}

//
// struct contained models a type that contains a type (for example std::pair)
// arrays are contained by value, and have to be treated as a special case:
//
template &lt;class T&gt;
struct contained
{
   // define our typedefs first, arrays are stored by value
   // so value_type is not the same as result_type:
   typedef typename boost::call_traits&lt;T&gt;::param_type       param_type;
   typedef typename boost::call_traits&lt;T&gt;::reference        reference;
   typedef typename boost::call_traits&lt;T&gt;::const_reference  const_reference;
   typedef T                                                value_type;
   typedef typename boost::call_traits&lt;T&gt;::value_type       result_type;

   // stored value:
   value_type v_;
   
   // constructors:
   contained() {}
   contained(param_type p) : v_(p){}
   // return byval:
   result_type value()const { return v_; }
   // return by_ref:
   reference get() { return v_; }
   const_reference const_get()const { return v_; }
   // pass value:
   void call(param_type){}
private:
   contained&amp; operator=(const contained&amp;);
};

#ifndef BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
template &lt;class T, std::size_t N&gt;
struct contained&lt;T[N]&gt;
{
   typedef typename boost::call_traits&lt;T[N]&gt;::param_type       param_type;
   typedef typename boost::call_traits&lt;T[N]&gt;::reference        reference;
   typedef typename boost::call_traits&lt;T[N]&gt;::const_reference  const_reference;
   typedef T                                                   value_type[N];
   typedef typename boost::call_traits&lt;T[N]&gt;::value_type       result_type;

   value_type v_;

   contained(param_type p)
   {
      std::copy(p, p+N, v_);
   }
   // return byval:
   result_type value()const { return v_; }
   // return by_ref:
   reference get() { return v_; }
   const_reference const_get()const { return v_; }
   void call(param_type){}
private:
   contained&amp; operator=(const contained&amp;);
};
#endif

template &lt;class T&gt;
contained&lt;typename boost::call_traits&lt;T&gt;::value_type&gt; test_wrap_type(const T&amp; t)
{
   typedef typename boost::call_traits&lt;T&gt;::value_type ct;
   return contained&lt;ct&gt;(t);
}

namespace test{

template &lt;class T1, class T2&gt;
std::pair&lt;
   typename boost::call_traits&lt;T1&gt;::value_type,
   typename boost::call_traits&lt;T2&gt;::value_type&gt;
      make_pair(const T1&amp; t1, const T2&amp; t2)
{
   return std::pair&lt;
      typename boost::call_traits&lt;T1&gt;::value_type,
      typename boost::call_traits&lt;T2&gt;::value_type&gt;(t1, t2);
}

} // namespace test

using namespace std;

//
// struct call_traits_checker:
// verifies behaviour of contained example:
//
template &lt;class T&gt;
struct call_traits_checker
{
   typedef typename boost::call_traits&lt;T&gt;::param_type param_type;
   void operator()(param_type);
};

template &lt;class T&gt;
void call_traits_checker&lt;T&gt;::operator()(param_type p)
{
   T t(p);
   contained&lt;T&gt; c(t);
   cout &lt;&lt; &quot;checking contained&lt;&quot; &lt;&lt; typeid(T).name() &lt;&lt; &quot;&gt;...&quot; &lt;&lt; endl;
   BOOST_CHECK(t == c.value());
   BOOST_CHECK(t == c.get());
   BOOST_CHECK(t == c.const_get());
#ifndef __ICL
   //cout &lt;&lt; &quot;typeof contained&lt;&quot; &lt;&lt; typeid(T).name() &lt;&lt; &quot;&gt;::v_ is:           &quot; &lt;&lt; typeid(&amp;contained&lt;T&gt;::v_).name() &lt;&lt; endl;
   cout &lt;&lt; &quot;typeof contained&lt;&quot; &lt;&lt; typeid(T).name() &lt;&lt; &quot;&gt;::value() is:      &quot; &lt;&lt; typeid(&amp;contained&lt;T&gt;::value).name() &lt;&lt; endl;
   cout &lt;&lt; &quot;typeof contained&lt;&quot; &lt;&lt; typeid(T).name() &lt;&lt; &quot;&gt;::get() is:        &quot; &lt;&lt; typeid(&amp;contained&lt;T&gt;::get).name() &lt;&lt; endl;
   cout &lt;&lt; &quot;typeof contained&lt;&quot; &lt;&lt; typeid(T).name() &lt;&lt; &quot;&gt;::const_get() is:  &quot; &lt;&lt; typeid(&amp;contained&lt;T&gt;::const_get).name() &lt;&lt; endl;
   cout &lt;&lt; &quot;typeof contained&lt;&quot; &lt;&lt; typeid(T).name() &lt;&lt; &quot;&gt;::call() is:       &quot; &lt;&lt; typeid(&amp;contained&lt;T&gt;::call).name() &lt;&lt; endl;
   cout &lt;&lt; endl;
#endif
}

#ifndef BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
template &lt;class T, std::size_t N&gt;
struct call_traits_checker&lt;T[N]&gt;
{
   typedef typename boost::call_traits&lt;T[N]&gt;::param_type param_type;
   void operator()(param_type t)
   {
      contained&lt;T[N]&gt; c(t);
      cout &lt;&lt; &quot;checking contained&lt;&quot; &lt;&lt; typeid(T[N]).name() &lt;&lt; &quot;&gt;...&quot; &lt;&lt; endl;
      unsigned int i = 0;
      for(i = 0; i &lt; N; ++i)
         BOOST_CHECK(t[i] == c.value()[i]);
      for(i = 0; i &lt; N; ++i)
         BOOST_CHECK(t[i] == c.get()[i]);
      for(i = 0; i &lt; N; ++i)
         BOOST_CHECK(t[i] == c.const_get()[i]);

      cout &lt;&lt; &quot;typeof contained&lt;&quot; &lt;&lt; typeid(T[N]).name() &lt;&lt; &quot;&gt;::v_ is:         &quot; &lt;&lt; typeid(&amp;contained&lt;T[N]&gt;::v_).name() &lt;&lt; endl;
      cout &lt;&lt; &quot;typeof contained&lt;&quot; &lt;&lt; typeid(T[N]).name() &lt;&lt; &quot;&gt;::value is:      &quot; &lt;&lt; typeid(&amp;contained&lt;T[N]&gt;::value).name() &lt;&lt; endl;
      cout &lt;&lt; &quot;typeof contained&lt;&quot; &lt;&lt; typeid(T[N]).name() &lt;&lt; &quot;&gt;::get is:        &quot; &lt;&lt; typeid(&amp;contained&lt;T[N]&gt;::get).name() &lt;&lt; endl;
      cout &lt;&lt; &quot;typeof contained&lt;&quot; &lt;&lt; typeid(T[N]).name() &lt;&lt; &quot;&gt;::const_get is:  &quot; &lt;&lt; typeid(&amp;contained&lt;T[N]&gt;::const_get).name() &lt;&lt; endl;
      cout &lt;&lt; &quot;typeof contained&lt;&quot; &lt;&lt; typeid(T[N]).name() &lt;&lt; &quot;&gt;::call is:       &quot; &lt;&lt; typeid(&amp;contained&lt;T[N]&gt;::call).name() &lt;&lt; endl;
      cout &lt;&lt; endl;
   }
};
#endif

//
// check_wrap:
template &lt;class W, class U&gt;
void check_wrap(const W&amp; w, const U&amp; u)
{
   cout &lt;&lt; &quot;checking &quot; &lt;&lt; typeid(W).name() &lt;&lt; &quot;...&quot; &lt;&lt; endl;
   BOOST_CHECK(w.value() == u);
}

//
// check_make_pair:
// verifies behaviour of &quot;make_pair&quot;:
//
template &lt;class T, class U, class V&gt;
void check_make_pair(T c, U u, V v)
{
   cout &lt;&lt; &quot;checking std::pair&lt;&quot; &lt;&lt; typeid(c.first).name() &lt;&lt; &quot;, &quot; &lt;&lt; typeid(c.second).name() &lt;&lt; &quot;&gt;...&quot; &lt;&lt; endl;
   BOOST_CHECK(c.first == u);
   BOOST_CHECK(c.second == v);
   cout &lt;&lt; endl;
}


struct comparible_UDT
{
   int i_;
   comparible_UDT() : i_(2){}
   comparible_UDT(const comparible_UDT&amp; other) : i_(other.i_){}
   comparible_UDT&amp; operator=(const comparible_UDT&amp; other)
   { 
      i_ = other.i_;
      return *this;
   }
   bool operator == (const comparible_UDT&amp; v){ return v.i_ == i_; }
};

int main()
{
   call_traits_checker&lt;comparible_UDT&gt; c1;
   comparible_UDT u;
   c1(u);
   call_traits_checker&lt;int&gt; c2;
   int i = 2;
   c2(i);
   int* pi = &amp;i;
   int a[2] = {1,2};
#if defined(BOOST_MSVC6_MEMBER_TEMPLATES) &amp;&amp; !defined(__ICL)
   call_traits_checker&lt;int*&gt; c3;
   c3(pi);
   call_traits_checker&lt;int&amp;&gt; c4;
   c4(i);
   call_traits_checker&lt;const int&amp;&gt; c5;
   c5(i);
#if !defined (BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION) &amp;&amp; !defined(__MWERKS__) &amp;&amp; !defined(__SUNPRO_CC)
   call_traits_checker&lt;int[2]&gt; c6;
   c6(a);
#endif
#endif

   check_wrap(test_wrap_type(2), 2);
#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION) &amp;&amp; !defined(__SUNPRO_CC)
   check_wrap(test_wrap_type(a), a);
   check_make_pair(test::make_pair(a, a), a, a);
#endif

   // cv-qualifiers applied to reference types should have no effect
   // declare these here for later use with is_reference and remove_reference:
   typedef int&amp; r_type;
   typedef const r_type cr_type;

   BOOST_CHECK_TYPE(comparible_UDT, boost::call_traits&lt;comparible_UDT&gt;::value_type);
   BOOST_CHECK_TYPE(comparible_UDT&amp;, boost::call_traits&lt;comparible_UDT&gt;::reference);
   BOOST_CHECK_TYPE(const comparible_UDT&amp;, boost::call_traits&lt;comparible_UDT&gt;::const_reference);
   BOOST_CHECK_TYPE(const comparible_UDT&amp;, boost::call_traits&lt;comparible_UDT&gt;::param_type);
   BOOST_CHECK_TYPE(int, boost::call_traits&lt;int&gt;::value_type);
   BOOST_CHECK_TYPE(int&amp;, boost::call_traits&lt;int&gt;::reference);
   BOOST_CHECK_TYPE(const int&amp;, boost::call_traits&lt;int&gt;::const_reference);
   BOOST_CHECK_TYPE(const int, boost::call_traits&lt;int&gt;::param_type);
   BOOST_CHECK_TYPE(int*, boost::call_traits&lt;int*&gt;::value_type);
   BOOST_CHECK_TYPE(int*&amp;, boost::call_traits&lt;int*&gt;::reference);
   BOOST_CHECK_TYPE(int*const&amp;, boost::call_traits&lt;int*&gt;::const_reference);
   BOOST_CHECK_TYPE(int*const, boost::call_traits&lt;int*&gt;::param_type);
#if defined(BOOST_MSVC6_MEMBER_TEMPLATES)
   BOOST_CHECK_TYPE(int&amp;, boost::call_traits&lt;int&amp;&gt;::value_type);
   BOOST_CHECK_TYPE(int&amp;, boost::call_traits&lt;int&amp;&gt;::reference);
   BOOST_CHECK_TYPE(const int&amp;, boost::call_traits&lt;int&amp;&gt;::const_reference);
   BOOST_CHECK_TYPE(int&amp;, boost::call_traits&lt;int&amp;&gt;::param_type);
#if !(defined(__GNUC__) &amp;&amp; ((__GNUC__ &lt; 3) || (__GNUC__ == 3) &amp;&amp; (__GNUC_MINOR__ &lt; 1)))
   BOOST_CHECK_TYPE(int&amp;, boost::call_traits&lt;cr_type&gt;::value_type);
   BOOST_CHECK_TYPE(int&amp;, boost::call_traits&lt;cr_type&gt;::reference);
   BOOST_CHECK_TYPE(const int&amp;, boost::call_traits&lt;cr_type&gt;::const_reference);
   BOOST_CHECK_TYPE(int&amp;, boost::call_traits&lt;cr_type&gt;::param_type);
#else
   std::cout &lt;&lt; &quot;Your compiler cannot instantiate call_traits&lt;int&amp;const&gt;, skipping four tests (4 errors)&quot; &lt;&lt; std::endl;
#endif
   BOOST_CHECK_TYPE(const int&amp;, boost::call_traits&lt;const int&amp;&gt;::value_type);
   BOOST_CHECK_TYPE(const int&amp;, boost::call_traits&lt;const int&amp;&gt;::reference);
   BOOST_CHECK_TYPE(const int&amp;, boost::call_traits&lt;const int&amp;&gt;::const_reference);
   BOOST_CHECK_TYPE(const int&amp;, boost::call_traits&lt;const int&amp;&gt;::param_type);
#ifndef BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
   BOOST_CHECK_TYPE(const int*, boost::call_traits&lt;int[3]&gt;::value_type);
   BOOST_CHECK_TYPE(int(&amp;)[3], boost::call_traits&lt;int[3]&gt;::reference);
   BOOST_CHECK_TYPE(const int(&amp;)[3], boost::call_traits&lt;int[3]&gt;::const_reference);
   BOOST_CHECK_TYPE(const int*const, boost::call_traits&lt;int[3]&gt;::param_type);
   BOOST_CHECK_TYPE(const int*, boost::call_traits&lt;const int[3]&gt;::value_type);
   BOOST_CHECK_TYPE(const int(&amp;)[3], boost::call_traits&lt;const int[3]&gt;::reference);
   BOOST_CHECK_TYPE(const int(&amp;)[3], boost::call_traits&lt;const int[3]&gt;::const_reference);
   BOOST_CHECK_TYPE(const int*const, boost::call_traits&lt;const int[3]&gt;::param_type);
   // test with abstract base class:
   BOOST_CHECK_TYPE(test_abc1, boost::call_traits&lt;test_abc1&gt;::value_type);
   BOOST_CHECK_TYPE(test_abc1&amp;, boost::call_traits&lt;test_abc1&gt;::reference);
   BOOST_CHECK_TYPE(const test_abc1&amp;, boost::call_traits&lt;test_abc1&gt;::const_reference);
   BOOST_CHECK_TYPE(const test_abc1&amp;, boost::call_traits&lt;test_abc1&gt;::param_type);
#else
   std::cout &lt;&lt; &quot;You're compiler does not support partial template specialiation, skipping 8 tests (8 errors)&quot; &lt;&lt; std::endl;
#endif
#else
   std::cout &lt;&lt; &quot;You're compiler does not support partial template specialiation, skipping 20 tests (20 errors)&quot; &lt;&lt; std::endl;
#endif
   // test with an incomplete type:
   BOOST_CHECK_TYPE(incomplete_type, boost::call_traits&lt;incomplete_type&gt;::value_type);
   BOOST_CHECK_TYPE(incomplete_type&amp;, boost::call_traits&lt;incomplete_type&gt;::reference);
   BOOST_CHECK_TYPE(const incomplete_type&amp;, boost::call_traits&lt;incomplete_type&gt;::const_reference);
   BOOST_CHECK_TYPE(const incomplete_type&amp;, boost::call_traits&lt;incomplete_type&gt;::param_type);

   return 0;
}

//
// define call_traits tests to check that the assertions in the docs do actually work
// this is an compile-time only set of tests:
//
template &lt;typename T, bool isarray = false&gt;
struct call_traits_test
{
   typedef ::boost::call_traits&lt;T&gt; ct;
   typedef typename ct::param_type param_type;
   typedef typename ct::reference reference;
   typedef typename ct::const_reference const_reference;
   typedef typename ct::value_type value_type;
   static void assert_construct(param_type val);
};

template &lt;typename T, bool isarray&gt;
void call_traits_test&lt;T, isarray&gt;::assert_construct(typename call_traits_test&lt;T, isarray&gt;::param_type val)
{
   //
   // this is to check that the call_traits assertions are valid:
   T t(val);
   value_type v(t);
   reference r(t);
   const_reference cr(t);
   param_type p(t);
   value_type v2(v);
   value_type v3(r);
   value_type v4(p);
   reference r2(v);
   reference r3(r);
   const_reference cr2(v);
   const_reference cr3(r);
   const_reference cr4(cr);
   const_reference cr5(p);
   param_type p2(v);
   param_type p3(r);
   param_type p4(p);
   
   unused_variable(v2);
   unused_variable(v3);
   unused_variable(v4);
   unused_variable(r2);
   unused_variable(r3);
   unused_variable(cr2);
   unused_variable(cr3);
   unused_variable(cr4);
   unused_variable(cr5);
   unused_variable(p2);
   unused_variable(p3);
   unused_variable(p4);
}
#ifndef BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
template &lt;typename T&gt;
struct call_traits_test&lt;T, true&gt;
{
   typedef ::boost::call_traits&lt;T&gt; ct;
   typedef typename ct::param_type param_type;
   typedef typename ct::reference reference;
   typedef typename ct::const_reference const_reference;
   typedef typename ct::value_type value_type;
   static void assert_construct(param_type val);
};

template &lt;typename T&gt;
void call_traits_test&lt;T, true&gt;::assert_construct(typename boost::call_traits&lt;T&gt;::param_type val)
{
   //
   // this is to check that the call_traits assertions are valid:
   T t;
   value_type v(t);
   value_type v5(val);
   reference r = t;
   const_reference cr = t;
   reference r2 = r;
   #ifndef __BORLANDC__
   // C++ Builder buglet:
   const_reference cr2 = r;
   #endif
   param_type p(t);
   value_type v2(v);
   const_reference cr3 = cr;
   value_type v3(r);
   value_type v4(p);
   param_type p2(v);
   param_type p3(r);
   param_type p4(p);
   
   unused_variable(v2);
   unused_variable(v3);
   unused_variable(v4);
   unused_variable(v5);
#ifndef __BORLANDC__
   unused_variable(r2);
   unused_variable(cr2);
#endif
   unused_variable(cr3);
   unused_variable(p2);
   unused_variable(p3);
   unused_variable(p4);
}
#endif //BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
//
// now check call_traits assertions by instantiating call_traits_test:
template struct call_traits_test&lt;int&gt;;
template struct call_traits_test&lt;const int&gt;;
template struct call_traits_test&lt;int*&gt;;
#if defined(BOOST_MSVC6_MEMBER_TEMPLATES)
template struct call_traits_test&lt;int&amp;&gt;;
template struct call_traits_test&lt;const int&amp;&gt;;
#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION) &amp;&amp; !defined(__SUNPRO_CC)
template struct call_traits_test&lt;int[2], true&gt;;
#endif
#endif

</pre>
            </div>
          </div>
        </div>
      </div>

      <div class="clear"></div>
    </div>
  </div>

  <div id="footer">
    <div id="footer-left">
      <div id="revised">
        <p>Revised $Date: 2010-09-26 09:11:52 -0400 (Sun, 26 Sep 2010) $</p>
      </div>

      <div id="copyright">
        <p>Copyright Beman Dawes, David Abrahams, 1998-2005.</p>

        <p>Copyright Rene Rivera 2004-2008.</p>
      </div>  <div id="license">
    <p>Distributed under the <a href="/LICENSE_1_0.txt" class=
    "internal">Boost Software License, Version 1.0</a>.</p>
  </div>
    </div>

    <div id="footer-right">
        <div id="banners">
    <p id="banner-xhtml"><a href="http://validator.w3.org/check?uri=referer"
    class="external">XHTML 1.0</a></p>

    <p id="banner-css"><a href=
    "http://jigsaw.w3.org/css-validator/check/referer" class=
    "external">CSS</a></p>

    <p id="banner-osi"><a href=
    "http://www.opensource.org/docs/definition.php" class="external">OSI
    Certified</a></p>
  </div>
    </div>

    <div class="clear"></div>
  </div>
</body>
</html>