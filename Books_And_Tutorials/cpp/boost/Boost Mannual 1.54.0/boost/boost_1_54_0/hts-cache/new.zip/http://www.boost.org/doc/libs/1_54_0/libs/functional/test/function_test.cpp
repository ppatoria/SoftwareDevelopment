<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=us-ascii" />
<title>libs/functional/test/function_test.cpp - 1.54.0</title>  <link rel="icon" href="/favicon.ico" type="image/ico" />
  <link rel="stylesheet" type="text/css" href="/style-v2/section-doc.css" />
  <!--[if IE 7]> <style type="text/css"> body { behavior: url(/style-v2/csshover3.htc); } </style> <![endif]-->

</head>

<body>
  <div id="heading">
    <div class="heading-inner">
  <div class="heading-placard"></div>

  <h1 class="heading-title">
  <a href="/">
  <img src="/gfx/space.png" alt= "Boost C++ Libraries" class="heading-logo" />
  <span class="heading-boost">Boost</span>
  <span class="heading-cpplibraries">C++ Libraries</span>
  </a></h1>

  <p class="heading-quote">
  <q>...one of the most highly
  regarded and expertly designed C++ library projects in the
  world.</q> <span class="heading-attribution">&mdash; <a href=
  "http://www.gotw.ca/" class="external">Herb Sutter</a> and <a href=
  "http://en.wikipedia.org/wiki/Andrei_Alexandrescu" class="external">Andrei
  Alexandrescu</a>, <a href=
  "http://safari.awprofessional.com/?XmlId=0321113586" class="external">C++
  Coding Standards</a></span></p>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33761719-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
  </div>

  <div id="body">
    <div id="body-inner">
      <div id="content">
        <div class="section" id="docs">
          <div class="section-0">
            <div class="section-body">
              <h3>libs/functional/test/function_test.cpp</h3>
<pre>
// ------------------------------------------------------------------------------
// Copyright (c) 2000 Cadenza New Zealand Ltd
// Distributed under the Boost Software License, Version 1.0. (See accompany-
// ing file LICENSE_1_0.txt or copy at <a href="http://www.boost.org/LICENSE_1_0.txt">http://www.boost.org/LICENSE_1_0.txt</a>)
// ------------------------------------------------------------------------------
// Tests for the Boost functional.hpp header file
//
// Note that functional.hpp relies on partial specialisation to be
// effective.  If your compiler lacks this feature, very few of the
// tests would compile, and so have been excluded from the test.
// ------------------------------------------------------------------------------
// $Id: function_test.cpp 50456 2009-01-04 05:17:02Z bgubenko $
// ------------------------------------------------------------------------------
// $Log$
// Revision 1.3  2006/12/02 13:57:32  andreas_huber69
// Fixed license &amp; copyright issues.
//
// From Mark Rodgers Fri Dec 1 12:59:14 2006
// X-Apparently-To: ahd6974-boostorg -at- yahoo.com via 68.142.206.160; Fri, 01 Dec 2006 12:59:41 -0800
// X-Originating-IP: [195.112.4.54]
// Return-Path: &lt;mark.rodgers -at- cadenza.co.nz&gt;
// Authentication-Results: mta550.mail.mud.yahoo.com from=cadenza.co.nz; domainkeys=neutral (no sig)
// Received: from 195.112.4.54 (EHLO smtp.nildram.co.uk) (195.112.4.54) by mta550.mail.mud.yahoo.com with SMTP; Fri, 01 Dec 2006 12:59:40 -0800
// Received: from snagglepuss.cadenza.co.nz (81-6-246-87.dyn.gotadsl.co.uk [81.6.246.87]) by smtp.nildram.co.uk (Postfix) with ESMTP id D32EA2B6D8C for &lt;ahd6974-boostorg -at- yahoo.com&gt;; Fri, 1 Dec 2006 20:59:35 +0000 (GMT)
// Received: from penfold.cadenza.co.nz ([192.168.55.56]) by snagglepuss.cadenza.co.nz with esmtp (Exim 4.63) (envelope-from &lt;mark.rodgers -at- cadenza.co.nz&gt;) id J9M4Y9-0009TO-9K for ahd6974-boostorg -at- yahoo.com; Fri, 01 Dec 2006 20:58:57 +0000
// Message-ID: &lt;457097A2.1090305@cadenza.co.nz&gt;
// Date: Fri, 01 Dec 2006 20:59:14 +0000
// From: &quot;Mark Rodgers&quot; &lt;mark.rodgers -at- cadenza.co.nz&gt;
// User-Agent: Thunderbird 1.5.0.8 (Macintosh/20061025)
// MIME-Version: 1.0
// To: ahd6974-boostorg -at- yahoo.com [Edit - Delete]
// Subject: Re: [boost] Reminder: Need your permission to correct license &amp; copyright issues
// References: &lt;379990.36007.qm@web33507.mail.mud.yahoo.com&gt;
// In-Reply-To: &lt;379990.36007.qm@web33507.mail.mud.yahoo.com&gt;
// Content-Type: text/plain; charset=ISO-8859-1; format=flowed
// Content-Transfer-Encoding: 7bit
// Content-Length: 812
// Gidday Andreas
//
// Sure that's fine.  I'm happy for you to do 1, 2 and 3.
//
// Regards
// Mark
//
// Andreas Huber wrote:
// &gt; Hello Mark
// &gt;
// &gt; Quite a while ago it was decided that every file that goes into the
// &gt; 1.34 release of the Boost distribution (www.boost.org) needs uniform
// &gt; license and copyright information. For more information please see:
// &gt;
// &gt; &lt;<a href="http://www.boost.org/more/license_info.html">http://www.boost.org/more/license_info.html</a>&gt;
// &gt;
// &gt; You are receiving this email because several files you contributed
// &gt; lack such information or have an old license:
// &gt;
// &gt; boost/functional/functional.hpp
// &gt; boost/libs/functional/binders.html
// &gt; boost/libs/functional/function_test.cpp
// &gt; boost/libs/functional/function_traits.html
// &gt; boost/libs/functional/index.html
// &gt; boost/libs/functional/mem_fun.html
// &gt; boost/libs/functional/negators.html
// &gt; boost/libs/functional/ptr_fun.html
// &gt; boost/people/mark_rodgers.htm
// &gt;
// &gt; I therefore kindly ask you to grant the permission to do the
// &gt; following:
// &gt;
// &gt; 1. For the files above that already have a license text (all except
// &gt; mark_rodgers.htm), replace the license text with:
// &gt;
// &gt; &quot;Distributed under the Boost Software License, Version 1.0. (See
// &gt; accompanying file LICENSE_1_0.txt or copy at
// &gt; <a href="http://www.boost.org/LICENSE_1_0.txt">http://www.boost.org/LICENSE_1_0.txt</a>)&quot;
// &gt;
// &gt; 2. For the file that does not yet have a license and copyright
// &gt; (mark_rodgers.htm) add the same license text as under 1. and add the
// &gt; following copyright:
// &gt;
// &gt; &quot;(c) Copyright Mark Rodgers 2000&quot;
// &gt;
// &gt; 3. (Optional) I would also want to convert all HTML files to conform
// &gt; the HTML 4.01 Standard by running them through HTML Tidy, see
// &gt; &lt;http://tidy.sf.net&gt;
// &gt;
// &gt; It would be great if you could grant me permission to do 1 &amp; 2 and
// &gt; optionally also 3.
// &gt;
// &gt; Thank you!
// &gt;
// &gt; Regards,
// &gt;
// &gt; Andreas Huber
// &gt;
//
// Revision 1.2  2001/09/22 11:52:24  johnmaddock
// Intel C++ fixes: no void return types supported.
//
// Revision 1.1.1.1  2000/07/07 16:04:18  beman
// 1.16.1 initial CVS checkin
//
// Revision 1.3  2000/06/26 09:44:01  mark
// Updated following feedback from Jens Maurer.
//
// Revision 1.2  2000/05/17 08:31:45  mark
// Added extra tests now that function traits work correctly.
// For compilers with no support for partial specialisation,
// excluded tests that won't work.
//
// Revision 1.1  2000/05/07 09:14:41  mark
// Initial revision
// ------------------------------------------------------------------------------

// To demonstrate what the boosted function object adapters do for
// you, try compiling with USE_STD defined.  This will endeavour to
// use the standard function object adapters, but is likely to result
// in numerous errors due to the fact that you cannot have references
// to references.
#ifdef USE_STD
#include &lt;functional&gt;
#define boost std
#else
#include &lt;<a href="../../../boost/functional.hpp">boost/functional.hpp</a>&gt;
#endif

#include &lt;algorithm&gt;
#include &lt;iostream&gt;
#include &lt;iterator&gt;
#include &lt;string&gt;
#include &lt;vector&gt;

class Person
{
  public:
    Person() {}
    Person(const char *n) : name(n) {}

    const std::string &amp;get_name() const { return name; }
    void print(std::ostream &amp;os) const { os &lt;&lt; name &lt;&lt; &quot; &quot;; }
    void set_name(const std::string &amp;n) { name = n; std::cout &lt;&lt; name &lt;&lt; &quot; &quot;; }
    std::string clear_name() { std::string ret = name; name = &quot;&quot;; return ret; }
    void do_something(int) const {}

    bool is_fred() const { return name == &quot;Fred&quot;; }
    
  private:
    std::string name;
};

namespace
{
    bool is_equal(const std::string &amp;s1, const std::string &amp;s2)
    {
        return s1 == s2;
    }

    bool is_betty(const std::string &amp;s)
    {
        return s == &quot;Betty&quot;;
    }

    void do_set_name(Person *p, const std::string &amp;name)
    {
        p-&gt;set_name(name);
    }
    
    void do_set_name_ref(Person &amp;p, const std::string &amp;name)
    {
        p.set_name(name);
    }
}

int main()
{
    std::vector&lt;Person&gt; v1;
    v1.push_back(&quot;Fred&quot;);
    v1.push_back(&quot;Wilma&quot;);
    v1.push_back(&quot;Barney&quot;);
    v1.push_back(&quot;Betty&quot;);

    const std::vector&lt;Person&gt; cv1(v1.begin(), v1.end());

    std::vector&lt;std::string&gt; v2;
    v2.push_back(&quot;Fred&quot;);
    v2.push_back(&quot;Wilma&quot;);
    v2.push_back(&quot;Barney&quot;);
    v2.push_back(&quot;Betty&quot;);

    Person person;
    Person &amp;r = person;

    Person fred(&quot;Fred&quot;);
    Person wilma(&quot;Wilma&quot;);
    Person barney(&quot;Barney&quot;);
    Person betty(&quot;Betty&quot;);
    std::vector&lt;Person*&gt; v3;
    v3.push_back(&amp;fred);
    v3.push_back(&amp;wilma);
    v3.push_back(&amp;barney);
    v3.push_back(&amp;betty);

    const std::vector&lt;Person*&gt; cv3(v3.begin(), v3.end());
    std::vector&lt;const Person*&gt; v3c(v3.begin(), v3.end());

    std::ostream &amp;os = std::cout;

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION) &amp;&amp; !defined(__ICL)
    // unary_traits, unary_negate
    std::transform(v2.begin(), v2.end(),
                   std::ostream_iterator&lt;bool&gt;(std::cout, &quot; &quot;),
                   boost::not1(is_betty));

    std::cout &lt;&lt; '\n';
    std::transform(v1.begin(), v1.end(),
                   std::ostream_iterator&lt;bool&gt;(std::cout, &quot; &quot;),
                   boost::not1(boost::mem_fun_ref(&amp;Person::is_fred)));

    // binary_traits, binary_negate
    std::cout &lt;&lt; '\n';
    std::transform(v2.begin(), v2.end(),
                   std::ostream_iterator&lt;bool&gt;(std::cout, &quot; &quot;),
                   boost::bind1st(boost::not2(is_equal), &quot;Betty&quot;));

    std::cout &lt;&lt; '\n';
    std::transform(v2.begin(), v2.end(),
                   std::ostream_iterator&lt;bool&gt;(std::cout, &quot; &quot;),
                   boost::bind2nd(boost::not2(is_equal), &quot;Betty&quot;));

    // pointer_to_unary_function
    std::cout &lt;&lt; '\n';
    std::transform(v2.begin(), v2.end(),
                   std::ostream_iterator&lt;bool&gt;(std::cout, &quot; &quot;),
                   boost::not1(boost::ptr_fun(is_betty)));

    // binary_traits, bind1st, bind2nd
    std::cout &lt;&lt; '\n';
    std::transform(v2.begin(), v2.end(),
                   std::ostream_iterator&lt;bool&gt;(std::cout, &quot; &quot;),
                   boost::bind1st(is_equal, &quot;Betty&quot;));

    std::cout &lt;&lt; '\n';
    std::transform(v2.begin(), v2.end(),
                   std::ostream_iterator&lt;bool&gt;(std::cout, &quot; &quot;),
                   boost::bind2nd(is_equal, &quot;Betty&quot;));

    // pointer_to_binary_function, bind1st
    std::cout &lt;&lt; '\n';
    std::for_each(v2.begin(), v2.end(), boost::bind1st(boost::ptr_fun(do_set_name), &amp;person));

    std::cout &lt;&lt; '\n';
    std::for_each(v2.begin(), v2.end(), boost::bind1st(boost::ptr_fun(do_set_name_ref), person));

    std::cout &lt;&lt; '\n';
    std::for_each(v2.begin(), v2.end(), boost::bind1st(boost::ptr_fun(do_set_name_ref), r));

    // binary_traits
    std::cout &lt;&lt; '\n';
    std::for_each(v2.begin(), v2.end(), boost::bind1st(do_set_name, &amp;person));

    std::cout &lt;&lt; '\n';
    std::for_each(v2.begin(), v2.end(), boost::bind1st(do_set_name_ref, person));

    std::cout &lt;&lt; '\n';
    std::for_each(v2.begin(), v2.end(), boost::bind1st(do_set_name_ref, r));
#endif

    // const_mem_fun_t
    std::cout &lt;&lt; '\n';
    std::transform(v3.begin(), v3.end(),
                   std::ostream_iterator&lt;std::string&gt;(std::cout, &quot; &quot;),
                   boost::mem_fun(&amp;Person::get_name));

    std::cout &lt;&lt; '\n';
    std::transform(cv3.begin(), cv3.end(),
                   std::ostream_iterator&lt;std::string&gt;(std::cout, &quot; &quot;),
                   boost::mem_fun(&amp;Person::get_name));

    std::cout &lt;&lt; '\n';
    std::transform(v3c.begin(), v3c.end(),
                   std::ostream_iterator&lt;std::string&gt;(std::cout, &quot; &quot;),
                   boost::mem_fun(&amp;Person::get_name));

    // const_mem_fun_ref_t
    std::cout &lt;&lt; '\n';
    std::transform(v1.begin(), v1.end(),
                   std::ostream_iterator&lt;std::string&gt;(std::cout, &quot; &quot;),
                   boost::mem_fun_ref(&amp;Person::get_name));

    std::cout &lt;&lt; '\n';
    std::transform(cv1.begin(), cv1.end(),
                   std::ostream_iterator&lt;std::string&gt;(std::cout, &quot; &quot;),
                   boost::mem_fun_ref(&amp;Person::get_name));

#ifndef BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
    // const_mem_fun1_t, bind2nd
    std::cout &lt;&lt; '\n';
    std::for_each(v3.begin(), v3.end(), boost::bind2nd(boost::mem_fun(&amp;Person::print), std::cout));

    std::cout &lt;&lt; '\n';
    std::for_each(v3.begin(), v3.end(), boost::bind2nd(boost::mem_fun(&amp;Person::print), os));

    // const_mem_fun1_ref_t, bind2nd
    std::cout &lt;&lt; '\n';
    std::for_each(v1.begin(), v1.end(), boost::bind2nd(boost::mem_fun_ref(&amp;Person::print), std::cout));

    std::cout &lt;&lt; '\n';
    std::for_each(v1.begin(), v1.end(), boost::bind2nd(boost::mem_fun_ref(&amp;Person::print), os));

    // mem_fun1_t, bind1st
    std::cout &lt;&lt; '\n';
    std::for_each(v2.begin(), v2.end(), boost::bind1st(boost::mem_fun(&amp;Person::set_name), &amp;person));

    // mem_fun1_ref_t, bind1st
    std::cout &lt;&lt; '\n';
    std::for_each(v2.begin(), v2.end(), boost::bind1st(boost::mem_fun_ref(&amp;Person::set_name), person));

    std::cout &lt;&lt; '\n';
    std::for_each(v2.begin(), v2.end(), boost::bind1st(boost::mem_fun_ref(&amp;Person::set_name), r));
#endif

    // mem_fun_t
    std::cout &lt;&lt; '\n';
    std::transform(v3.begin(), v3.end(), std::ostream_iterator&lt;std::string&gt;(std::cout, &quot; &quot;),
                   boost::mem_fun(&amp;Person::clear_name));
    
    // mem_fun_ref_t
    std::cout &lt;&lt; '\n';
    std::transform(v1.begin(), v1.end(), std::ostream_iterator&lt;std::string&gt;(std::cout, &quot; &quot;),
                   boost::mem_fun_ref(&amp;Person::clear_name));    

    std::cout &lt;&lt; '\n';
    return 0;
}
</pre>
            </div>
          </div>
        </div>
      </div>

      <div class="clear"></div>
    </div>
  </div>

  <div id="footer">
    <div id="footer-left">
      <div id="revised">
        <p>Revised $Date: 2010-09-26 09:11:52 -0400 (Sun, 26 Sep 2010) $</p>
      </div>

      <div id="copyright">
        <p>Copyright Beman Dawes, David Abrahams, 1998-2005.</p>

        <p>Copyright Rene Rivera 2004-2008.</p>
      </div>  <div id="license">
    <p>Distributed under the <a href="/LICENSE_1_0.txt" class=
    "internal">Boost Software License, Version 1.0</a>.</p>
  </div>
    </div>

    <div id="footer-right">
        <div id="banners">
    <p id="banner-xhtml"><a href="http://validator.w3.org/check?uri=referer"
    class="external">XHTML 1.0</a></p>

    <p id="banner-css"><a href=
    "http://jigsaw.w3.org/css-validator/check/referer" class=
    "external">CSS</a></p>

    <p id="banner-osi"><a href=
    "http://www.opensource.org/docs/definition.php" class="external">OSI
    Certified</a></p>
  </div>
    </div>

    <div class="clear"></div>
  </div>
</body>
</html>