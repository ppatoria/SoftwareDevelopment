<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=us-ascii" />
<title>boost/detail/call_traits.hpp - 1.54.0</title>  <link rel="icon" href="/favicon.ico" type="image/ico" />
  <link rel="stylesheet" type="text/css" href="/style-v2/section-doc.css" />
  <!--[if IE 7]> <style type="text/css"> body { behavior: url(/style-v2/csshover3.htc); } </style> <![endif]-->

</head>

<body>
  <div id="heading">
    <div class="heading-inner">
  <div class="heading-placard"></div>

  <h1 class="heading-title">
  <a href="/">
  <img src="/gfx/space.png" alt= "Boost C++ Libraries" class="heading-logo" />
  <span class="heading-boost">Boost</span>
  <span class="heading-cpplibraries">C++ Libraries</span>
  </a></h1>

  <p class="heading-quote">
  <q>...one of the most highly
  regarded and expertly designed C++ library projects in the
  world.</q> <span class="heading-attribution">&mdash; <a href=
  "http://www.gotw.ca/" class="external">Herb Sutter</a> and <a href=
  "http://en.wikipedia.org/wiki/Andrei_Alexandrescu" class="external">Andrei
  Alexandrescu</a>, <a href=
  "http://safari.awprofessional.com/?XmlId=0321113586" class="external">C++
  Coding Standards</a></span></p>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33761719-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
  </div>

  <div id="body">
    <div id="body-inner">
      <div id="content">
        <div class="section" id="docs">
          <div class="section-0">
            <div class="section-body">
              <h3>boost/detail/call_traits.hpp</h3>
<pre>
//  (C) Copyright Steve Cleary, Beman Dawes, Howard Hinnant &amp; John Maddock 2000.
//  Use, modification and distribution are subject to the Boost Software License,
//  Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  <a href="http://www.boost.org/LICENSE_1_0.txt">http://www.boost.org/LICENSE_1_0.txt</a>).
//
//  See <a href="http://www.boost.org/libs/utility">http://www.boost.org/libs/utility</a> for most recent version including documentation.

// call_traits: defines typedefs for function usage
// (see libs/utility/call_traits.htm)

/* Release notes:
   23rd July 2000:
      Fixed array specialization. (JM)
      Added Borland specific fixes for reference types
      (issue raised by Steve Cleary).
*/

#ifndef BOOST_DETAIL_CALL_TRAITS_HPP
#define BOOST_DETAIL_CALL_TRAITS_HPP

#ifndef BOOST_CONFIG_HPP
#include &lt;<a href="../../boost/config.hpp">boost/config.hpp</a>&gt;
#endif
#include &lt;cstddef&gt;

#include &lt;<a href="../../boost/type_traits/is_arithmetic.hpp">boost/type_traits/is_arithmetic.hpp</a>&gt;
#include &lt;<a href="../../boost/type_traits/is_enum.hpp">boost/type_traits/is_enum.hpp</a>&gt;
#include &lt;<a href="../../boost/type_traits/is_pointer.hpp">boost/type_traits/is_pointer.hpp</a>&gt;
#include &lt;<a href="../../boost/detail/workaround.hpp">boost/detail/workaround.hpp</a>&gt;

namespace boost{

namespace detail{

template &lt;typename T, bool small_&gt;
struct ct_imp2
{
   typedef const T&amp; param_type;
};

template &lt;typename T&gt;
struct ct_imp2&lt;T, true&gt;
{
   typedef const T param_type;
};

template &lt;typename T, bool isp, bool b1, bool b2&gt;
struct ct_imp
{
   typedef const T&amp; param_type;
};

template &lt;typename T, bool isp, bool b2&gt;
struct ct_imp&lt;T, isp, true, b2&gt;
{
   typedef typename ct_imp2&lt;T, sizeof(T) &lt;= sizeof(void*)&gt;::param_type param_type;
};

template &lt;typename T, bool isp, bool b1&gt;
struct ct_imp&lt;T, isp, b1, true&gt;
{
   typedef typename ct_imp2&lt;T, sizeof(T) &lt;= sizeof(void*)&gt;::param_type param_type;
};

template &lt;typename T, bool b1, bool b2&gt;
struct ct_imp&lt;T, true, b1, b2&gt;
{
   typedef const T param_type;
};

}

template &lt;typename T&gt;
struct call_traits
{
public:
   typedef T value_type;
   typedef T&amp; reference;
   typedef const T&amp; const_reference;
   //
   // C++ Builder workaround: we should be able to define a compile time
   // constant and pass that as a single template parameter to ct_imp&lt;T,bool&gt;,
   // however compiler bugs prevent this - instead pass three bool's to
   // ct_imp&lt;T,bool,bool,bool&gt; and add an extra partial specialisation
   // of ct_imp to handle the logic. (JM)
   typedef typename boost::detail::ct_imp&lt;
      T,
      ::boost::is_pointer&lt;T&gt;::value,
      ::boost::is_arithmetic&lt;T&gt;::value,
      ::boost::is_enum&lt;T&gt;::value
   &gt;::param_type param_type;
};

template &lt;typename T&gt;
struct call_traits&lt;T&amp;&gt;
{
   typedef T&amp; value_type;
   typedef T&amp; reference;
   typedef const T&amp; const_reference;
   typedef T&amp; param_type;  // hh removed const
};

#if BOOST_WORKAROUND( __BORLANDC__,  &lt; 0x5A0 )
// these are illegal specialisations; cv-qualifies applied to
// references have no effect according to [8.3.2p1],
// C++ Builder requires them though as it treats cv-qualified
// references as distinct types...
template &lt;typename T&gt;
struct call_traits&lt;T&amp;const&gt;
{
   typedef T&amp; value_type;
   typedef T&amp; reference;
   typedef const T&amp; const_reference;
   typedef T&amp; param_type;  // hh removed const
};
template &lt;typename T&gt;
struct call_traits&lt;T&amp;volatile&gt;
{
   typedef T&amp; value_type;
   typedef T&amp; reference;
   typedef const T&amp; const_reference;
   typedef T&amp; param_type;  // hh removed const
};
template &lt;typename T&gt;
struct call_traits&lt;T&amp;const volatile&gt;
{
   typedef T&amp; value_type;
   typedef T&amp; reference;
   typedef const T&amp; const_reference;
   typedef T&amp; param_type;  // hh removed const
};

template &lt;typename T&gt;
struct call_traits&lt; T * &gt;
{
   typedef T * value_type;
   typedef T * &amp; reference;
   typedef T * const &amp; const_reference;
   typedef T * const param_type;  // hh removed const
};
#endif
#if !defined(BOOST_NO_ARRAY_TYPE_SPECIALIZATIONS)
template &lt;typename T, std::size_t N&gt;
struct call_traits&lt;T [N]&gt;
{
private:
   typedef T array_type[N];
public:
   // degrades array to pointer:
   typedef const T* value_type;
   typedef array_type&amp; reference;
   typedef const array_type&amp; const_reference;
   typedef const T* const param_type;
};

template &lt;typename T, std::size_t N&gt;
struct call_traits&lt;const T [N]&gt;
{
private:
   typedef const T array_type[N];
public:
   // degrades array to pointer:
   typedef const T* value_type;
   typedef array_type&amp; reference;
   typedef const array_type&amp; const_reference;
   typedef const T* const param_type;
};
#endif

}

#endif // BOOST_DETAIL_CALL_TRAITS_HPP
</pre>
            </div>
          </div>
        </div>
      </div>

      <div class="clear"></div>
    </div>
  </div>

  <div id="footer">
    <div id="footer-left">
      <div id="revised">
        <p>Revised $Date: 2010-09-26 09:11:52 -0400 (Sun, 26 Sep 2010) $</p>
      </div>

      <div id="copyright">
        <p>Copyright Beman Dawes, David Abrahams, 1998-2005.</p>

        <p>Copyright Rene Rivera 2004-2008.</p>
      </div>  <div id="license">
    <p>Distributed under the <a href="/LICENSE_1_0.txt" class=
    "internal">Boost Software License, Version 1.0</a>.</p>
  </div>
    </div>

    <div id="footer-right">
        <div id="banners">
    <p id="banner-xhtml"><a href="http://validator.w3.org/check?uri=referer"
    class="external">XHTML 1.0</a></p>

    <p id="banner-css"><a href=
    "http://jigsaw.w3.org/css-validator/check/referer" class=
    "external">CSS</a></p>

    <p id="banner-osi"><a href=
    "http://www.opensource.org/docs/definition.php" class="external">OSI
    Certified</a></p>
  </div>
    </div>

    <div class="clear"></div>
  </div>
</body>
</html>