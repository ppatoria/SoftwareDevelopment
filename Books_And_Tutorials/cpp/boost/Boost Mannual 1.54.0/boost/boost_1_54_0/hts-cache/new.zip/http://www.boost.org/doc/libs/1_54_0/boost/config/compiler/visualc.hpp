<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=us-ascii" />
<title>boost/config/compiler/visualc.hpp - 1.54.0</title>  <link rel="icon" href="/favicon.ico" type="image/ico" />
  <link rel="stylesheet" type="text/css" href="/style-v2/section-doc.css" />
  <!--[if IE 7]> <style type="text/css"> body { behavior: url(/style-v2/csshover3.htc); } </style> <![endif]-->

</head>

<body>
  <div id="heading">
    <div class="heading-inner">
  <div class="heading-placard"></div>

  <h1 class="heading-title">
  <a href="/">
  <img src="/gfx/space.png" alt= "Boost C++ Libraries" class="heading-logo" />
  <span class="heading-boost">Boost</span>
  <span class="heading-cpplibraries">C++ Libraries</span>
  </a></h1>

  <p class="heading-quote">
  <q>...one of the most highly
  regarded and expertly designed C++ library projects in the
  world.</q> <span class="heading-attribution">&mdash; <a href=
  "http://www.gotw.ca/" class="external">Herb Sutter</a> and <a href=
  "http://en.wikipedia.org/wiki/Andrei_Alexandrescu" class="external">Andrei
  Alexandrescu</a>, <a href=
  "http://safari.awprofessional.com/?XmlId=0321113586" class="external">C++
  Coding Standards</a></span></p>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33761719-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
  </div>

  <div id="body">
    <div id="body-inner">
      <div id="content">
        <div class="section" id="docs">
          <div class="section-0">
            <div class="section-body">
              <h3>boost/config/compiler/visualc.hpp</h3>
<pre>
//  (C) Copyright John Maddock 2001 - 2003. 
//  (C) Copyright Darin Adler 2001 - 2002. 
//  (C) Copyright Peter Dimov 2001. 
//  (C) Copyright Aleksey Gurtovoy 2002. 
//  (C) Copyright David Abrahams 2002 - 2003. 
//  (C) Copyright Beman Dawes 2002 - 2003. 
//  Use, modification and distribution are subject to the 
//  Boost Software License, Version 1.0. (See accompanying file 
//  LICENSE_1_0.txt or copy at <a href="http://www.boost.org/LICENSE_1_0.txt">http://www.boost.org/LICENSE_1_0.txt</a>)

//  See http://www.boost.org for most recent version.
//
//  Microsoft Visual C++ compiler setup:
//
//  We need to be careful with the checks in this file, as contrary
//  to popular belief there are versions with _MSC_VER with the final
//  digit non-zero (mainly the MIPS cross compiler).
//
//  So we either test _MSC_VER &gt;= XXXX or else _MSC_VER &lt; XXXX.
//  No other comparisons (==, &gt;, or &lt;=) are safe.
//

#define BOOST_MSVC _MSC_VER

//
// Helper macro BOOST_MSVC_FULL_VER for use in Boost code:
//
#if _MSC_FULL_VER &gt; 100000000
#  define BOOST_MSVC_FULL_VER _MSC_FULL_VER
#else
#  define BOOST_MSVC_FULL_VER (_MSC_FULL_VER * 10)
#endif

// Attempt to suppress VC6 warnings about the length of decorated names (obsolete):
#pragma warning( disable : 4503 ) // warning: decorated name length exceeded

//
// versions check:
// we don't support Visual C++ prior to version 6:
#if _MSC_VER &lt; 1200
#  error &quot;Compiler not supported or configured - please reconfigure&quot;
#endif

#if _MSC_VER &lt; 1300  // 1200 == VC++ 6.0, 1200-1202 == eVC++4
#  pragma warning( disable : 4786 ) // ident trunc to '255' chars in debug info
#  define BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
#  define BOOST_NO_VOID_RETURNS
#  define BOOST_NO_EXCEPTION_STD_NAMESPACE

#  if _MSC_VER == 1202
#    define BOOST_NO_STD_TYPEINFO
#  endif

#endif

/// Visual Studio has no fenv.h
#define BOOST_NO_FENV_H

#if (_MSC_VER &lt; 1310)  // 130X == VC++ 7.0

#  if !defined(_MSC_EXTENSIONS) &amp;&amp; !defined(BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS)      // VC7 bug with /Za
#    define BOOST_NO_DEPENDENT_TYPES_IN_TEMPLATE_VALUE_PARAMETERS
#  endif

#  define BOOST_NO_EXPLICIT_FUNCTION_TEMPLATE_ARGUMENTS
#  define BOOST_NO_INCLASS_MEMBER_INITIALIZATION
#  define BOOST_NO_PRIVATE_IN_AGGREGATE
#  define BOOST_NO_ARGUMENT_DEPENDENT_LOOKUP
#  define BOOST_NO_INTEGRAL_INT64_T
#  define BOOST_NO_DEDUCED_TYPENAME
#  define BOOST_NO_USING_DECLARATION_OVERLOADS_FROM_TYPENAME_BASE

//    VC++ 6/7 has member templates but they have numerous problems including
//    cases of silent failure, so for safety we define:
#  define BOOST_NO_MEMBER_TEMPLATES
//    For VC++ experts wishing to attempt workarounds, we define:
#  define BOOST_MSVC6_MEMBER_TEMPLATES

#  define BOOST_NO_MEMBER_TEMPLATE_FRIENDS
#  define BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
#  define BOOST_NO_CV_VOID_SPECIALIZATIONS
#  define BOOST_NO_FUNCTION_TEMPLATE_ORDERING
#  define BOOST_NO_USING_TEMPLATE
#  define BOOST_NO_SWPRINTF
#  define BOOST_NO_TEMPLATE_TEMPLATES
#  define BOOST_NO_SFINAE
#  define BOOST_NO_POINTER_TO_MEMBER_TEMPLATE_PARAMETERS
#  define BOOST_NO_IS_ABSTRACT
#  define BOOST_NO_FUNCTION_TYPE_SPECIALIZATIONS
// TODO: what version is meant here? Have there really been any fixes in cl 12.01 (as e.g. shipped with eVC4)?
#  if (_MSC_VER &gt;= 1300)
#     define BOOST_NO_MEMBER_FUNCTION_SPECIALIZATIONS
#  endif

#endif

#if _MSC_VER &lt; 1400 
// although a conforming signature for swprint exists in VC7.1
// it appears not to actually work:
#  define BOOST_NO_SWPRINTF
// Our extern template tests also fail for this compiler:
#  define BOOST_NO_CXX11_EXTERN_TEMPLATE
// Variadic macros do not exist for VC7.1 and lower
#  define BOOST_NO_CXX11_VARIADIC_MACROS
#endif

#if defined(UNDER_CE)
// Windows CE does not have a conforming signature for swprintf
#  define BOOST_NO_SWPRINTF
#endif

#if _MSC_VER &lt; 1500  // 140X == VC++ 8.0
#  define BOOST_NO_MEMBER_TEMPLATE_FRIENDS
#endif

#if _MSC_VER &lt; 1600  // 150X == VC++ 9.0
   // A bug in VC9:
#  define BOOST_NO_ADL_BARRIER
#endif


// MSVC (including the latest checked version) has not yet completely 
// implemented value-initialization, as is reported:
// &quot;VC++ does not value-initialize members of derived classes without 
// user-declared constructor&quot;, reported in 2009 by Sylvester Hesp:
// <a href="https://connect.microsoft.com/VisualStudio/feedback/details/484295">https://connect.microsoft.com/VisualStudio/feedback/details/484295</a>
// &quot;Presence of copy constructor breaks member class initialization&quot;,
// reported in 2009 by Alex Vakulenko:
// <a href="https://connect.microsoft.com/VisualStudio/feedback/details/499606">https://connect.microsoft.com/VisualStudio/feedback/details/499606</a>
// &quot;Value-initialization in new-expression&quot;, reported in 2005 by
// Pavel Kuznetsov (MetaCommunications Engineering):
// <a href="https://connect.microsoft.com/VisualStudio/feedback/details/100744">https://connect.microsoft.com/VisualStudio/feedback/details/100744</a>
// See also: <a href="http://www.boost.org/libs/utility/value_init.htm#compiler_issues">http://www.boost.org/libs/utility/value_init.htm#compiler_issues</a>
// (Niels Dekker, LKEB, May 2010)
#  define BOOST_NO_COMPLETE_VALUE_INITIALIZATION

#ifndef _NATIVE_WCHAR_T_DEFINED
#  define BOOST_NO_INTRINSIC_WCHAR_T
#endif

#if defined(_WIN32_WCE) || defined(UNDER_CE)
#  define BOOST_NO_SWPRINTF
#endif

// we have ThreadEx or GetSystemTimeAsFileTime unless we're running WindowsCE
#if !defined(_WIN32_WCE) &amp;&amp; !defined(UNDER_CE)
#  define BOOST_HAS_THREADEX
#  define BOOST_HAS_GETSYSTEMTIMEASFILETIME
#endif

//   
// check for exception handling support:   
#if !defined(_CPPUNWIND) &amp;&amp; !defined(BOOST_NO_EXCEPTIONS)
#  define BOOST_NO_EXCEPTIONS   
#endif 

//
// __int64 support:
//
#if (_MSC_VER &gt;= 1200)
#   define BOOST_HAS_MS_INT64
#endif
#if (_MSC_VER &gt;= 1310) &amp;&amp; (defined(_MSC_EXTENSIONS) || (_MSC_VER &gt;= 1400))
#   define BOOST_HAS_LONG_LONG
#else
#   define BOOST_NO_LONG_LONG
#endif
#if (_MSC_VER &gt;= 1400) &amp;&amp; !defined(_DEBUG)
#   define BOOST_HAS_NRVO
#endif
//
// disable Win32 API's if compiler extentions are
// turned off:
//
#if !defined(_MSC_EXTENSIONS) &amp;&amp; !defined(BOOST_DISABLE_WIN32)
#  define BOOST_DISABLE_WIN32
#endif
#if !defined(_CPPRTTI) &amp;&amp; !defined(BOOST_NO_RTTI)
#  define BOOST_NO_RTTI
#endif

//
// TR1 features:
//
#if _MSC_VER &gt;= 1700
// # define BOOST_HAS_TR1_HASH			// don't know if this is true yet.
// # define BOOST_HAS_TR1_TYPE_TRAITS	// don't know if this is true yet.
# define BOOST_HAS_TR1_UNORDERED_MAP
# define BOOST_HAS_TR1_UNORDERED_SET
#endif

//
// C++0x features
//
//   See above for BOOST_NO_LONG_LONG

// C++ features supported by VC++ 10 (aka 2010)
//
#if _MSC_VER &lt; 1600
#  define BOOST_NO_CXX11_AUTO_DECLARATIONS
#  define BOOST_NO_CXX11_AUTO_MULTIDECLARATIONS
#  define BOOST_NO_CXX11_LAMBDAS
#  define BOOST_NO_CXX11_RVALUE_REFERENCES
#  define BOOST_NO_CXX11_STATIC_ASSERT
#  define BOOST_NO_CXX11_NULLPTR
#  define BOOST_NO_CXX11_DECLTYPE
#endif // _MSC_VER &lt; 1600

#if _MSC_VER &gt;= 1600
#  define BOOST_HAS_STDINT_H
#endif

// C++ features supported by VC++ 11 (aka 2012)
//
#if _MSC_VER &lt; 1700
#  define BOOST_NO_CXX11_RANGE_BASED_FOR
#  define BOOST_NO_CXX11_SCOPED_ENUMS
#endif // _MSC_VER &lt; 1700

// C++11 features supported by VC++ 11 (aka 2012) November 2012 CTP
// Because the CTP is unsupported, unrelease, and only alpha quality,
// it is only supported if BOOST_MSVC_ENABLE_2012_NOV_CTP is defined.
//
#if _MSC_FULL_VER &lt; 170051025 || !defined(BOOST_MSVC_ENABLE_2012_NOV_CTP)
#  define BOOST_NO_CXX11_EXPLICIT_CONVERSION_OPERATORS
#  define BOOST_NO_CXX11_FUNCTION_TEMPLATE_DEFAULT_ARGS
#  define BOOST_NO_CXX11_RAW_LITERALS
#  define BOOST_NO_CXX11_VARIADIC_TEMPLATES
#  define BOOST_NO_CXX11_UNIFIED_INITIALIZATION_SYNTAX
#endif

// C++11 features not supported by any versions
#define BOOST_NO_CXX11_CHAR16_T
#define BOOST_NO_CXX11_CHAR32_T
#define BOOST_NO_CXX11_CONSTEXPR
#define BOOST_NO_CXX11_DECLTYPE_N3276
#define BOOST_NO_CXX11_DEFAULTED_FUNCTIONS
#define BOOST_NO_CXX11_DELETED_FUNCTIONS
#define BOOST_NO_CXX11_NOEXCEPT
#define BOOST_NO_CXX11_TEMPLATE_ALIASES
#define BOOST_NO_CXX11_UNICODE_LITERALS
#define BOOST_NO_SFINAE_EXPR
#define BOOST_NO_TWO_PHASE_NAME_LOOKUP
#define BOOST_NO_CXX11_USER_DEFINED_LITERALS

//
// prefix and suffix headers:
//
#ifndef BOOST_ABI_PREFIX
#  define BOOST_ABI_PREFIX &quot;boost/config/abi/msvc_prefix.hpp&quot;
#endif
#ifndef BOOST_ABI_SUFFIX
#  define BOOST_ABI_SUFFIX &quot;boost/config/abi/msvc_suffix.hpp&quot;
#endif

#ifndef BOOST_COMPILER
// TODO:
// these things are mostly bogus. 1200 means version 12.0 of the compiler. The 
// artificial versions assigned to them only refer to the versions of some IDE
// these compilers have been shipped with, and even that is not all of it. Some
// were shipped with freely downloadable SDKs, others as crosscompilers in eVC.
// IOW, you can't use these 'versions' in any sensible way. Sorry.
# if defined(UNDER_CE)
#   if _MSC_VER &lt; 1200
      // Note: these are so far off, they are not really supported
#   elif _MSC_VER &lt; 1300 // eVC++ 4 comes with 1200-1202
#     define BOOST_COMPILER_VERSION evc4.0
#   elif _MSC_VER &lt; 1400
      // Note: I'm not aware of any CE compiler with version 13xx
#      if defined(BOOST_ASSERT_CONFIG)
#         error &quot;Unknown EVC++ compiler version - please run the configure tests and report the results&quot;
#      else
#         pragma message(&quot;Unknown EVC++ compiler version - please run the configure tests and report the results&quot;)
#      endif
#   elif _MSC_VER &lt; 1500
#     define BOOST_COMPILER_VERSION evc8
#   elif _MSC_VER &lt; 1600
#     define BOOST_COMPILER_VERSION evc9
#   elif _MSC_VER &lt; 1700
#     define BOOST_COMPILER_VERSION evc10
#   elif _MSC_VER &lt; 1800 
#     define BOOST_COMPILER_VERSION evc11 
#   else
#      if defined(BOOST_ASSERT_CONFIG)
#         error &quot;Unknown EVC++ compiler version - please run the configure tests and report the results&quot;
#      else
#         pragma message(&quot;Unknown EVC++ compiler version - please run the configure tests and report the results&quot;)
#      endif
#   endif
# else
#   if _MSC_VER &lt; 1200
      // Note: these are so far off, they are not really supported
#     define BOOST_COMPILER_VERSION 5.0
#   elif _MSC_VER &lt; 1300
#       define BOOST_COMPILER_VERSION 6.0
#   elif _MSC_VER &lt; 1310
#     define BOOST_COMPILER_VERSION 7.0
#   elif _MSC_VER &lt; 1400
#     define BOOST_COMPILER_VERSION 7.1
#   elif _MSC_VER &lt; 1500
#     define BOOST_COMPILER_VERSION 8.0
#   elif _MSC_VER &lt; 1600
#     define BOOST_COMPILER_VERSION 9.0
#   elif _MSC_VER &lt; 1700
#     define BOOST_COMPILER_VERSION 10.0
#   elif _MSC_VER &lt; 1800 
#     define BOOST_COMPILER_VERSION 11.0 
#   else
#     define BOOST_COMPILER_VERSION _MSC_VER
#   endif
# endif

#  define BOOST_COMPILER &quot;Microsoft Visual C++ version &quot; BOOST_STRINGIZE(BOOST_COMPILER_VERSION)
#endif

//
// last known and checked version is 1700 (VC11, aka 2011):
#if (_MSC_VER &gt; 1700)
#  if defined(BOOST_ASSERT_CONFIG)
#     error &quot;Unknown compiler version - please run the configure tests and report the results&quot;
#  else
#     pragma message(&quot;Unknown compiler version - please run the configure tests and report the results&quot;)
#  endif
#endif
</pre>
            </div>
          </div>
        </div>
      </div>

      <div class="clear"></div>
    </div>
  </div>

  <div id="footer">
    <div id="footer-left">
      <div id="revised">
        <p>Revised $Date: 2010-09-26 09:11:52 -0400 (Sun, 26 Sep 2010) $</p>
      </div>

      <div id="copyright">
        <p>Copyright Beman Dawes, David Abrahams, 1998-2005.</p>

        <p>Copyright Rene Rivera 2004-2008.</p>
      </div>  <div id="license">
    <p>Distributed under the <a href="/LICENSE_1_0.txt" class=
    "internal">Boost Software License, Version 1.0</a>.</p>
  </div>
    </div>

    <div id="footer-right">
        <div id="banners">
    <p id="banner-xhtml"><a href="http://validator.w3.org/check?uri=referer"
    class="external">XHTML 1.0</a></p>

    <p id="banner-css"><a href=
    "http://jigsaw.w3.org/css-validator/check/referer" class=
    "external">CSS</a></p>

    <p id="banner-osi"><a href=
    "http://www.opensource.org/docs/definition.php" class="external">OSI
    Certified</a></p>
  </div>
    </div>

    <div class="clear"></div>
  </div>
</body>
</html>