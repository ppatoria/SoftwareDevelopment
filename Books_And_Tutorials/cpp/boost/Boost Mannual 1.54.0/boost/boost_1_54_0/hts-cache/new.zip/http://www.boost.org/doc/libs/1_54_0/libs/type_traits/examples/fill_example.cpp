<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=us-ascii" />
<title>libs/type_traits/examples/fill_example.cpp - 1.54.0</title>  <link rel="icon" href="/favicon.ico" type="image/ico" />
  <link rel="stylesheet" type="text/css" href="/style-v2/section-doc.css" />
  <!--[if IE 7]> <style type="text/css"> body { behavior: url(/style-v2/csshover3.htc); } </style> <![endif]-->

</head>

<body>
  <div id="heading">
    <div class="heading-inner">
  <div class="heading-placard"></div>

  <h1 class="heading-title">
  <a href="/">
  <img src="/gfx/space.png" alt= "Boost C++ Libraries" class="heading-logo" />
  <span class="heading-boost">Boost</span>
  <span class="heading-cpplibraries">C++ Libraries</span>
  </a></h1>

  <p class="heading-quote">
  <q>...one of the most highly
  regarded and expertly designed C++ library projects in the
  world.</q> <span class="heading-attribution">&mdash; <a href=
  "http://www.gotw.ca/" class="external">Herb Sutter</a> and <a href=
  "http://en.wikipedia.org/wiki/Andrei_Alexandrescu" class="external">Andrei
  Alexandrescu</a>, <a href=
  "http://safari.awprofessional.com/?XmlId=0321113586" class="external">C++
  Coding Standards</a></span></p>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33761719-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
  </div>

  <div id="body">
    <div id="body-inner">
      <div id="content">
        <div class="section" id="docs">
          <div class="section-0">
            <div class="section-body">
              <h3>libs/type_traits/examples/fill_example.cpp</h3>
<pre>

/*
 *
 * (C) Copyright John Maddock 1999-2005. 
 * Use, modification and distribution are subject to the 
 * Boost Software License, Version 1.0. (See accompanying file 
 * LICENSE_1_0.txt or copy at <a href="http://www.boost.org/LICENSE_1_0.txt">http://www.boost.org/LICENSE_1_0.txt</a>)
 *
 * This file provides some example of type_traits usage -
 * by &quot;optimising&quot; various algorithms:
 *
 * opt::fill - optimised for trivial copy/small types (cf std::fill)
 *
 */

#include &lt;iostream&gt;
#include &lt;typeinfo&gt;
#include &lt;algorithm&gt;
#include &lt;iterator&gt;
#include &lt;memory&gt;
#include &lt;cstring&gt;

#include &lt;<a href="../../../boost/test/included/prg_exec_monitor.hpp">boost/test/included/prg_exec_monitor.hpp</a>&gt;
#include &lt;<a href="../../../boost/timer.hpp">boost/timer.hpp</a>&gt;
#include &lt;<a href="../../../boost/type_traits.hpp">boost/type_traits.hpp</a>&gt;

#if defined(BOOST_NO_STDC_NAMESPACE) || (defined(std) &amp;&amp; defined(__SGI_STL_PORT))
namespace std{ using :: memset; }
#endif

using std::cout;
using std::endl;
using std::cin;

namespace opt{
//
// fill
// same as std::fill, but uses memset where appropriate
//
namespace detail{

template &lt;typename I, typename T, bool b&gt;
void do_fill(I first, I last, const T&amp; val, const boost::integral_constant&lt;bool, b&gt;&amp;)
{
   while(first != last)
   {
      *first = val;
      ++first;
   }
}

template &lt;typename T&gt;
void do_fill(T* first, T* last, const T&amp; val, const boost::true_type&amp;)
{
   std::memset(first, val, last-first);
}

}

template &lt;class I, class T&gt;
inline void fill(I first, I last, const T&amp; val)
{
   //
   // We can do an optimised fill if T has a trivial assignment 
   // operator and if it's size is one:
   //
   typedef boost::integral_constant&lt;bool, 
      ::boost::has_trivial_assign&lt;T&gt;::value &amp;&amp; (sizeof(T) == 1)&gt; truth_type;
   detail::do_fill(first, last, val, truth_type());
}

}   // namespace opt

namespace non_opt{

template &lt;class I, class T&gt;
inline void fill(I first, I last, const T&amp; val)
{
   opt::detail::do_fill(first, last, val, boost::false_type());
}

}

//
// define some global data:
//
const int array_size = 1000;
int i_array_[array_size] = {0,};
const int ci_array_[array_size] = {0,};
char c_array_[array_size] = {0,};
const char cc_array_[array_size] = { 0,};
//
// since arrays aren't iterators we define a set of pointer
// aliases into the arrays (otherwise the compiler is entitled
// to deduce the type passed to the template functions as
// T (&amp;)[N] rather than T*).
int* i_array = i_array_;
const int* ci_array = ci_array_;
char* c_array = c_array_;
const char* cc_array = cc_array_;

const int iter_count = 1000000;

int cpp_main(int argc, char* argv[])
{
   boost::timer t;
   double result;
   int i;
   //
   // test destroy_array,
   // compare destruction time of an array of ints
   // with unoptimised form.
   //
   cout &lt;&lt; &quot;Measuring times in micro-seconds per 1000 elements processed&quot; &lt;&lt; endl &lt;&lt; endl;

   cout &lt;&lt; &quot;testing fill(char)...\n&quot;
   &quot;[Some standard library versions may already perform this optimisation.]&quot; &lt;&lt; endl;

   // cache load:
   opt::fill(c_array, c_array + array_size, (char)3);

   // time optimised version:
   t.restart();
   for(i = 0; i &lt; iter_count; ++i)
   {
      opt::fill(c_array, c_array + array_size, (char)3);
   }
   result = t.elapsed();
   cout &lt;&lt; &quot;opt::fill&lt;char*, char&gt;: &quot; &lt;&lt; result &lt;&lt; endl;

   // cache load:
   non_opt::fill(c_array, c_array + array_size, (char)3);

   // time optimised version:
   t.restart();
   for(i = 0; i &lt; iter_count; ++i)
   {
      non_opt::fill(c_array, c_array + array_size, (char)3);
   }
   result = t.elapsed();
   cout &lt;&lt; &quot;non_opt::fill&lt;char*, char&gt;: &quot; &lt;&lt; result &lt;&lt; endl;

   // cache load:
   std::fill(c_array, c_array + array_size, (char)3);

   // time standard version:
   t.restart();
   for(i = 0; i &lt; iter_count; ++i)
   {
      std::fill(c_array, c_array + array_size, (char)3);
   }
   result = t.elapsed();
   cout &lt;&lt; &quot;std::fill&lt;char*, char&gt;: &quot; &lt;&lt; result &lt;&lt; endl &lt;&lt; endl;

   cout &lt;&lt; &quot;testing fill(int)...\n&quot; &lt;&lt; endl;

   // cache load:
   opt::fill(i_array, i_array + array_size, 3);

   // timer optimised version:
   t.restart();
   for(i = 0; i &lt; iter_count; ++i)
   {
      opt::fill(i_array, i_array + array_size, 3);
   }
   result = t.elapsed();
   cout &lt;&lt; &quot;opt::fill&lt;int*, int&gt;: &quot; &lt;&lt; result &lt;&lt; endl;

   // cache load:
   non_opt::fill(i_array, i_array + array_size, 3);

   // timer optimised version:
   t.restart();
   for(i = 0; i &lt; iter_count; ++i)
   {
      non_opt::fill(i_array, i_array + array_size, 3);
   }
   result = t.elapsed();
   cout &lt;&lt; &quot;non_opt::fill&lt;int*, int&gt;: &quot; &lt;&lt; result &lt;&lt; endl;

   // cache load:
   std::fill(i_array, i_array + array_size, 3);

   // time standard version:
   t.restart();
   for(i = 0; i &lt; iter_count; ++i)
   {
      std::fill(i_array, i_array + array_size, 3);
   }
   result = t.elapsed();
   cout &lt;&lt; &quot;std::fill&lt;int*, int&gt;: &quot; &lt;&lt; result &lt;&lt; endl &lt;&lt; endl;

   return 0;
}






</pre>
            </div>
          </div>
        </div>
      </div>

      <div class="clear"></div>
    </div>
  </div>

  <div id="footer">
    <div id="footer-left">
      <div id="revised">
        <p>Revised $Date: 2010-09-26 09:11:52 -0400 (Sun, 26 Sep 2010) $</p>
      </div>

      <div id="copyright">
        <p>Copyright Beman Dawes, David Abrahams, 1998-2005.</p>

        <p>Copyright Rene Rivera 2004-2008.</p>
      </div>  <div id="license">
    <p>Distributed under the <a href="/LICENSE_1_0.txt" class=
    "internal">Boost Software License, Version 1.0</a>.</p>
  </div>
    </div>

    <div id="footer-right">
        <div id="banners">
    <p id="banner-xhtml"><a href="http://validator.w3.org/check?uri=referer"
    class="external">XHTML 1.0</a></p>

    <p id="banner-css"><a href=
    "http://jigsaw.w3.org/css-validator/check/referer" class=
    "external">CSS</a></p>

    <p id="banner-osi"><a href=
    "http://www.opensource.org/docs/definition.php" class="external">OSI
    Certified</a></p>
  </div>
    </div>

    <div class="clear"></div>
  </div>
</body>
</html>