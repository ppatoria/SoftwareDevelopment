﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Windows.Forms;

namespace ParallelLinq
{
    class MandelbrotGenerator
    {
        const int MaxIterations = 2000;
        const double SampleWidth = 3.2;
        const double SampleHeight = 2.5;
        const double OffsetX = -2.1;
        const double OffsetY = -1.25;

        const int ImageWidth = 1200;
        const int ImageHeight = (int)(SampleHeight * ImageWidth / SampleWidth);

        static byte ComputeMandelbrotIndex(int row, int col)
        {
            double x = (col * SampleWidth) / ImageWidth + OffsetX;
            double y = (row * SampleHeight) / ImageHeight + OffsetY;
                
            double y0 = y;
            double x0 = x;

            for (int i=0; i < MaxIterations; i++)
            {
                if (x*x+y*y >= 4)
                {
                    return (byte)((i%255)+1);
                }
                double xtemp = x*x - y*y + x0;
                y = 2*x*y + y0;
                x = xtemp;
            }
            return 0;
        }       

        public static void Main()
        {
            Stopwatch timer = Stopwatch.StartNew();

            var points = from row in Enumerable.Range(0, ImageHeight)
                         from col in Enumerable.Range(0, ImageWidth)
                         select new { row, col };

            var query = from point in points.AsParallel(ParallelQueryOptions.PreserveOrdering)                                              
                        select ComputeMandelbrotIndex(point.row, point.col);

            byte[] data = query.ToArray();

            Console.WriteLine("Generation took {0}ms", timer.ElapsedMilliseconds);

            unsafe
            {
                fixed (byte* ptr = data)
                {
                    IntPtr scan0 = new IntPtr(ptr);
                    Bitmap bitmap = new Bitmap(ImageWidth, ImageHeight, ImageWidth, PixelFormat.Format8bppIndexed, scan0);
                    ColorPalette palette = bitmap.Palette;
                    palette.Entries[0] = Color.Black;
                    for (int i=1; i < 256; i++)
                    {
                        palette.Entries[i] = Color.FromArgb((i*7)%256, (i*7)%256, 255);
                    }
                    bitmap.Palette = palette;

                    PictureBox pb = new PictureBox();
                    pb.Image = bitmap;
                    pb.Dock = DockStyle.Fill;

                    Form form = new Form();
                    form.FormBorderStyle = FormBorderStyle.FixedSingle;                    
                    form.Controls.Add(pb);
                    form.ClientSize = bitmap.Size;
                    form.Text = "Mandelbrot";

                    Application.Run(form);
                }
            }
        }
    }
}
