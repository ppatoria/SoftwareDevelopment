﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Threading;

using MiscUtil;
using System.Diagnostics;

namespace ParallelLinq
{
    /// <summary>
    /// Note that this listing has been extended to include diagnostics which make
    /// the parallelism clearer.
    /// </summary>
    [Description("Listing 12.22")]
    class RandomSleep
    {
        static int ObtainLengthSlowly(string name)
        {
            Console.WriteLine("Obtaining length on thread ID: " + Thread.CurrentThread.ManagedThreadId);
            Thread.Sleep(StaticRandom.Next(10000));
            return name.Length;
        }

        public static void Main()
        {
            string[] names = { "Jon", "Holly", "Tom", "Robin", "William" };

            var query = from name in names.AsParallel(3)
                        select ObtainLengthSlowly(name);

            Stopwatch sw = Stopwatch.StartNew();
            foreach (int length in query)
            {
                Console.WriteLine(length);
            }
            Console.WriteLine("Total time: {0}ms", sw.ElapsedMilliseconds);
        }
    }
}
