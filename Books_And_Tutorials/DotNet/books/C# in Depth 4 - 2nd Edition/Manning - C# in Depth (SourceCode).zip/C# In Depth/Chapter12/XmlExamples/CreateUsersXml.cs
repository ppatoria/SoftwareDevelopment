﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Xml.Linq;

using Model;

namespace XmlExamples
{
    [Description("Listing 12.14")]
    class CreateUsersXml
    {
        static void Main()
        {
            var users = new XElement("users",
                from user in SampleData.AllUsers
                select new XElement("user",
                    new XAttribute("name", user.Name),
                    new XAttribute("type", user.UserType))
            );

            Console.WriteLine(users);
        }
    }
}
