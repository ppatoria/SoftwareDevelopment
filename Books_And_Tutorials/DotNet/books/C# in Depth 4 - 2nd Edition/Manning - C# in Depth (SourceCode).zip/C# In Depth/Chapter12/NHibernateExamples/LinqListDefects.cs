﻿using System;
using System.Linq;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Linq;
using NHibernateExamples.Model;

namespace NHibernateExamples
{
    class LinqListDefects
    {
        static void Main()
        {
            ISessionFactory sessionFactory =
                new Configuration().Configure().BuildSessionFactory();

            using (ISession session = sessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var query = from defect in session.Linq<Defect>()
                                select defect;

                    foreach (Defect defect in query)
                    {
                        Console.Out.WriteLine(defect);
                    }

                    tx.Commit();
                }
            }
        }
    }
}
