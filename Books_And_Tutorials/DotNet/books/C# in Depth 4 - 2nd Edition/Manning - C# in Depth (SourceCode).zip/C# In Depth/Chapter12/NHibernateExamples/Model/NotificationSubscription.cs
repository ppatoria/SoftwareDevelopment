﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NHibernateExamples.Model
{
    public class NotificationSubscription
    {
        public virtual int NotificationSubscriptionID { get; set; }
        public virtual string EmailAddress { get; set; }
        public virtual Project Project { get; set; }
    }
}
