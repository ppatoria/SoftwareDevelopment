﻿using System;

using NHibernate;
using NHibernate.Cfg;
using NHibernateExamples.Model;

namespace NHibernateExamples
{
    class NonLinqListDefects
    {
        static void Main()
        {
            ISessionFactory sessionFactory =
                new Configuration().Configure().BuildSessionFactory();

            using (ISession session = sessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    ICriteria crit = session.CreateCriteria(typeof(Defect))
                                            .SetFetchMode("CreatedBy", FetchMode.Join)
                                            .SetFetchMode("AssignedTo", FetchMode.Join)
                                            .SetFetchMode("Project", FetchMode.Join);
                    foreach (Defect defect in crit.List())
                    {
                        Console.Out.WriteLine(defect);
                    }

                    tx.Commit();
                }
            }
        }
    }
}
