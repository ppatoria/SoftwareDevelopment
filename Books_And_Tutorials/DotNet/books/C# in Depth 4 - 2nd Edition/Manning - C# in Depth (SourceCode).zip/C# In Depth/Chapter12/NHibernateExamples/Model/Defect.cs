﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NHibernateExamples.Model
{
    public class Defect
    {
        public virtual Project Project { get; set; }
        public virtual User AssignedTo { get; set; }
        public virtual string Summary { get; set; }
        public virtual Severity Severity { get; set; }
        public virtual Status Status { get; set; }
        public virtual DateTime Created { get; set; }
        public virtual DateTime LastModified { get; set; }
        public virtual User CreatedBy { get; set; }
        public virtual int ID { get; private set; }

        public override string ToString()
        {
            return string.Format("{0,2}: {1}\r\n    {2}\r\n    ({3:d}-{4:d}, {5}/{6}, {7} -> {8})",
                ID, Summary, Project.Name, Created, LastModified, Severity, Status, CreatedBy.Name,
                AssignedTo == null ? "n/a" : AssignedTo.Name);
        }
    }
}
