﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHibernateExamples.Model
{
    public enum UserType
    {
        Customer,
        Developer,
        Tester,
        Manager,
    }
}
