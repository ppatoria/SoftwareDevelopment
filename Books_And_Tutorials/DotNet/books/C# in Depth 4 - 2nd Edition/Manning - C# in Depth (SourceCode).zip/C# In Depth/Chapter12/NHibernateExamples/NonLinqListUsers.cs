﻿using System;

using NHibernate;
using NHibernate.Cfg;
using NHibernateExamples.Model;

namespace NHibernateExamples
{
    class NonLinqListUsers
    {
        static void Main()
        {
            ISessionFactory sessionFactory =
                new Configuration().Configure().BuildSessionFactory();

            using (ISession session = sessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    ICriteria crit = session.CreateCriteria(typeof(User));
                    foreach (User user in crit.List())
                    {
                        Console.Out.WriteLine("{0}: {1}", user.Name, user.UserType);
                    }

                    tx.Commit();
                }
            }
        }
    }
}
