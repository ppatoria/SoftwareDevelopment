﻿using System;
using System.Linq;
using System.ComponentModel;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Linq;
using NHibernateExamples.Model;

namespace NHibernateExamples
{
    [Description("Listing 12.20")]
    class LinqShowAllOpenDefectsAssignedToTim
    {
        static void Main()
        {
            ISessionFactory sessionFactory =
                new Configuration().Configure().BuildSessionFactory();

            using (ISession session = sessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    User tim = (from user in session.Linq<User>()
                                where user.Name == "Tim Trotter"
                                select user).Single();

                    var query = from defect in session.Linq<Defect>()
                                where defect.Status != Status.Closed
                                where defect.AssignedTo == tim
                                select defect.Summary;

                    foreach (var summary in query)
                    {
                        Console.WriteLine(summary);
                    }
                    tx.Commit();
                }
            }
        }
    }
}
