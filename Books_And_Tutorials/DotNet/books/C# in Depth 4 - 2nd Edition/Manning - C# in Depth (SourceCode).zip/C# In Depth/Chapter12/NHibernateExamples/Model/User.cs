﻿namespace NHibernateExamples.Model
{
    public class User
    {
        public virtual string Name { get; set; }
        public virtual UserType UserType { get; set; }
        public virtual int UserId { get; set; }

        public override string ToString()
        {
            return string.Format ("{0} ({1})", Name, UserType);
        }
    }
}
