﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHibernateExamples.Model
{
    public class Project
    {
        public virtual string Name { get; set; }
        public virtual int ProjectId { get; set; }
    }
}
