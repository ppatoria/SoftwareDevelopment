﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NHibernateExamples.Model
{
    public enum Severity
    {
        Trivial,
        Minor,
        Major,
        Showstopper,
    }
}
