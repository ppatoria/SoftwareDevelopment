﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml.Linq;

namespace LinqInAction.Chapter12.LinqToAmazon
{
  public static class AmazonHelper
  {
    private const String NAMESPACE_AWSECommerceService = "http://webservices.amazon.com/AWSECommerceService/2005-10-05";
    private const String URL_AWSECommerceService = "http://webservices.amazon.com/onca/xml?Service=AWSECommerceService&AWSAccessKeyId={0}&Operation=ItemSearch&SearchIndex=Books&ResponseGroup=Medium";

    static internal String BuildUrl(AmazonBookQueryCriteria criteria, string accessId)
    {
      if (criteria == null)
        throw new ArgumentNullException("criteria");

      String url = string.Format(URL_AWSECommerceService, accessId);

      if (!String.IsNullOrEmpty(criteria.Title))
        url += "&Title=" + HttpUtility.UrlEncode(criteria.Title);
      if (!String.IsNullOrEmpty(criteria.Publisher))
        url += "&Publisher=" + HttpUtility.UrlEncode(criteria.Publisher);
      if (criteria.Condition.HasValue)
        url += "&Condition=" + HttpUtility.UrlEncode(criteria.Condition.ToString());
      if (criteria.MaximumPrice.HasValue)
        url += "&MaximumPrice=" + HttpUtility.UrlEncode(
          (criteria.MaximumPrice * 100).Value.ToString(CultureInfo.InvariantCulture));

      return url;
    }

    static internal IEnumerable<AmazonBook> PerformWebQuery(String url)
    {
      // Execute query
      XElement booksDoc = XElement.Load(url);

      // Parse results
      XNamespace ns = NAMESPACE_AWSECommerceService;
      IEnumerable<AmazonBook> books =
        from book in booksDoc.Descendants(ns + "Item")
        let attributes = book.Element(ns + "ItemAttributes")
        let isbn = attributes.Element(ns + "ISBN")
        let price = attributes.Element(ns + "ListPrice").Element(ns + "Amount").Value
        select new AmazonBook
           {
             Title = attributes.Element(ns + "Title").Value,
             Isbn = isbn==null ? null : isbn.Value,
             PageCount = UInt32.Parse(attributes.Element(ns + "NumberOfPages").Value),
             Price = price != null ? Decimal.Parse(price) / 100 : 0,
             Publisher = attributes.Element(ns + "Publisher").Value,
             Year = UInt32.Parse(
               ((String)attributes.Element(ns + "PublicationDate").Value).Substring(0, 4)),
             Authors = (
               from author in book.Descendants(ns + "Author")
               select (String)author.Value
             ).ToList()
           };

      return books;
    }
  }
}
