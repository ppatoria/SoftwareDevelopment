﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using DataSetExamples.DefectDataSetTableAdapters;

namespace DataSetExamples
{
    class TypedGroupOpenDefectSummariesByStatus
    {
        static void Main()
        {
            DefectDataSet dataSet = new DefectDataSet();

            var query = from defect in dataSet.Defect
            where defect.Status != Status.Closed
            group defect by defect.Status;

            new DefectTableAdapter().Fill(dataSet.Defect);
            new UserTableAdapter().Fill(dataSet.User);
            new ProjectTableAdapter().Fill(dataSet.Project);

            foreach (var group in query)
            {
                Console.WriteLine (group.Key);
                foreach (var defect in group)
                {
                    Console.WriteLine ("  {0}: {1}/{2}",
                                       defect.ID, 
                                       defect.ProjectRow.Name, 
                                       defect.UserRowByAssignedTo.Name);
                }
            }
        }
    }
}
