﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;

using DataSetExamples.Properties;
using Model;

namespace DataSetExamples
{
    [Description("Listing 12.10")]
    class UntypedShowOpenDefectSummaries
    {
        static void Main()
        {
            DataTable dataTable = new DataTable();

            using (var connection = new SqlConnection
                (Settings.Default.SkeetySoftDefectsConnectionString))
            {
                string sql = "SELECT Summary, Status FROM Defect";
                new SqlDataAdapter(sql, connection).Fill(dataTable);
            }

            var query = from defect in dataTable.AsEnumerable()
                        where defect.Field<Status>("Status") != Status.Closed
                        select defect.Field<string>("Summary");

            foreach (string summary in query)
            {
                Console.WriteLine(summary);
            }
        }
    }
}
