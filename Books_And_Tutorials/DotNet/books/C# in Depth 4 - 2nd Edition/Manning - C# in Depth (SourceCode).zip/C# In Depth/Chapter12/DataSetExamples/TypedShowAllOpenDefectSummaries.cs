﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using DataSetExamples.DefectDataSetTableAdapters;
using System.ComponentModel;

namespace DataSetExamples
{
    [Description("Listing 12.11")]
    class TypedShowAllOpenDefectSummaries
    {
        static void Main()
        {
            DefectDataSet dataSet = new DefectDataSet();
            new DefectTableAdapter().Fill(dataSet.Defect);

            var query = from defect in dataSet.Defect
                        where defect.Status != Status.Closed
                        select defect.Summary;

            foreach (string summary in query)
            {
                Console.WriteLine (summary);
            }
        }
    }
}
