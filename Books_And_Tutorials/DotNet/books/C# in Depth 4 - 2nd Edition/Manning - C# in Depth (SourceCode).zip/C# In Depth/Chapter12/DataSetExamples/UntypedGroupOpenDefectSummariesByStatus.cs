﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

using DataSetExamples.Properties;
using Model;

namespace DataSetExamples
{
    [Description("Listing 12.12")]
    class UntypedGroupOpenDefectSummariesByStatus
    {
        static void Main()
        {
            DataTable dataTable = new DataTable();

            using (var connection = new SqlConnection
                (Settings.Default.SkeetySoftDefectsConnectionString))
            {
                string sql = "SELECT Summary, Status from Defect";

                new SqlDataAdapter(sql, connection).Fill(dataTable);
            }

            var query = from defect in dataTable.AsEnumerable()
                        let status = defect.Field<Status>("Status")
                        where status != Status.Closed
                        group defect.Field<string>("Summary") by status;

            foreach (var statusSummaryCollection in query)
            {
                Console.WriteLine (statusSummaryCollection.Key);
                foreach (string summary in statusSummaryCollection)
                {
                    Console.WriteLine ("  {0}", summary);
                }
                Console.WriteLine();
            }
        }
    }
}
