﻿using System;
using System.Data;
using System.Data.SqlClient;

using DataSetExamples.Properties;
using Model;

namespace DataSetExamples
{
    class UntypedShowOpenDefectDetails
    {
        static void Main()
        {
            DataSet dataSet = new DataSet();

            using (var connection = new SqlConnection
                (Settings.Default.SkeetySoftDefectsConnectionString))
            {
                string sql = "SELECT * from Defect";
                using (var adapter = new SqlDataAdapter(sql, connection))
                {
                    adapter.Fill(dataSet, "Defect");
                }

                sql = "SELECT * from DefectUser";
                using (var adapter = new SqlDataAdapter(sql, connection))
                {
                    adapter.Fill(dataSet, "DefectUser");
                }
            }

            DataRelation relation = new DataRelation("Assignee", 
                                                     dataSet.Tables["DefectUser"].Columns["UserId"],
                                                     dataSet.Tables["Defect"].Columns["AssignedToUserId"]);
            dataSet.Relations.Add(relation);


            var query = from defect in dataSet.Tables["Defect"].AsEnumerable()
                        where defect.Field<Status>("Status") != Status.Closed
                        select new { ID=defect.Field<int>("DefectID"),
                                     Assignee=defect.GetParentRow(relation).Field<string>("Name") };

            foreach (var defect in query)
            {
                Console.WriteLine ("{0}: {1}", defect.ID, defect.Assignee);
            }
        }
    }
}
