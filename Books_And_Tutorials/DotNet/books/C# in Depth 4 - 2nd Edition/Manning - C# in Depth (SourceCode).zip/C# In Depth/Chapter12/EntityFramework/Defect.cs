﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityFramework.Model
{
    partial class Defect
    {
        public override string ToString()
        {
            // Note: this is pretty grim. When I learn more about the
            // entity framework, I'm likely to improve it!
            if (CreatorReference != null)
            {
                CreatorReference.Load();
            }
            if (AssigneeReference != null)
            {
                AssigneeReference.Load();
            }
            return string.Format("{0,2}: {1}\r\n    ({2:d}-{3:d}, {4}/{5}, {6} -> {7})",
                DefectID, Summary, Created, LastModified, Severity, Status, Creator.Name,
                Assignee == null ? "n/a" : Assignee.Name);
        }
    }
}

