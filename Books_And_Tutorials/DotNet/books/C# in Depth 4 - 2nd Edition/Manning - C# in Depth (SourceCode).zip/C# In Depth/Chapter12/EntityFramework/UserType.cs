﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntityFramework.Model
{
    public enum UserType : byte
    {
        Customer,
        Developer,
        Tester,
        Manager,
    }
}
