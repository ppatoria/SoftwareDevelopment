﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EntityFramework.Model;

namespace EntityFramework
{
    class ShowAllClosedDefects
    {
        static void Main()
        {
            using (var connection = new DefectModel())
            {
                var query = from defect in connection.Defect
                            where defect.Status == (byte)Status.Closed
                            select defect;

                foreach (var defect in query)
                {
                    Console.WriteLine(defect);
                }
            }
        }
    }
}
