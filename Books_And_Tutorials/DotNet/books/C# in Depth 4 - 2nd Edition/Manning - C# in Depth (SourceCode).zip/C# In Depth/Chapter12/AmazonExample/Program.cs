﻿using System;
using System.ComponentModel;
using System.Linq;

using LinqInAction.Chapter12.LinqToAmazon;

namespace AmazonExample
{
    [Description("Listing 12.19")]
    class Program
    {
        static void Main(string[] args)
        {
            AmazonBookSearch source = new AmazonBookSearch("INSERT YOUR ID HERE");

            var webQuery = from book in source                       
                           where book.Title.Contains("LINQ")         
                           select book;                              

            var query = from book in webQuery.AsEnumerable()         
                        orderby book.Year, book.Title                 
                        select book;                                 

            foreach (AmazonBook book in query)                        
            {                                                         
                Console.WriteLine ("{0}: {1}", book.Year, book.Title); 
            }                                                          

            Console.ReadLine();
        }
    }
}
