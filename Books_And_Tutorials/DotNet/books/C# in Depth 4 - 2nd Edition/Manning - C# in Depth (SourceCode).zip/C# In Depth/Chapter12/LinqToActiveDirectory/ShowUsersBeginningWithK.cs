﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

using BdsSoft.DirectoryServices.Linq;
using System.DirectoryServices;

namespace LinqToActiveDirectory
{
    [Description("Listing 12.21")]
    class ShowUsersBeginningWithK
    {
        // See http://www.codeplex.com/LINQtoAD for more details
        public static void Main()
        {
            string url = "LDAP://ldap.andrew.cmu.edu/dc=cmu,dc=edu";
            DirectoryEntry root = new DirectoryEntry(url);
            root.AuthenticationType = AuthenticationTypes.None;

            var users = new DirectorySource<Person>(root, SearchScope.Subtree);
            users.Log = Console.Out;

            var query = from user in users 
                        where user.FirstName.StartsWith("K")
                        select user;

            foreach (Person person in query)
            {
                Console.WriteLine (person.DisplayName);
                foreach (string title in person.Titles)
                {
                    Console.WriteLine("  {0}", title);
                }
            }
        }
    }
}
