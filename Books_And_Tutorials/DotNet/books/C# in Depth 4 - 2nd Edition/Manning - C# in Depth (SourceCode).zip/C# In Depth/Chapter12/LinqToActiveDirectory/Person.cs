﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BdsSoft.DirectoryServices.Linq;

namespace LinqToActiveDirectory
{
    [DirectorySchema("person")]
    class Person
    {
        [DirectoryAttribute("cn")]
        public string DisplayName { get; set; }
        [DirectoryAttribute("description")]
        public string Description { get; set; }
        [DirectoryAttribute("mail")]
        public string Mail { get; set; }
        [DirectoryAttribute("givenName")]
        public string FirstName { get; set; }
        [DirectoryAttribute("sn")]
        public string Surname { get; set; }

        [DirectoryAttribute("title")]
        public string[] Titles { get; set; }
    }
}
