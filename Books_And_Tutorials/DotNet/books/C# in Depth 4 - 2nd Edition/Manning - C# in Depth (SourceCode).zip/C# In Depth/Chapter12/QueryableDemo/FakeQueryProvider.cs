﻿using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;

namespace QueryableDemo
{
    [Description("Listing 12.7")]
    class FakeQueryProvider : IQueryProvider
    {
        public IQueryable<T> CreateQuery<T>(Expression expression)
        {
            Logger.Log(this, expression);
            return new FakeQuery<T>(this, expression);
        }

        public IQueryable CreateQuery(Expression expression)
        {
            Logger.Log(this, expression);
            return new FakeQuery<object>(this, expression);
        }

        public T Execute<T>(Expression expression)
        {
            Logger.Log(this, expression);
            return default(T);
        }

        public object Execute(Expression expression)
        {
            Logger.Log(this, expression);
            return null;
        }
    }
}
