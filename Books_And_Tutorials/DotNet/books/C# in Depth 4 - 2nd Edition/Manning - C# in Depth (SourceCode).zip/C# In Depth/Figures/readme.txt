This directory contains diagrams for various query expressions - the 
expanded versions of the ones in chapter 11, and some other 
interesting queries. If there's a query expression I haven't drawn
which you'd like me to, please mail me: skeet@pobox.com

The diagrams are all drawn with Dia 
(http://dia-installer.de/index_en.html)
and then converted to PDF using CutePDF Writer
(http://cutepdf.com) and Ghostscript (http://ghostscript.com)


