README for C# In Depth source code
----------------------------------

The source code for C# In Depth is laid out in the following manner:

MiscUtil.dll: Required for most solutions, to allow easy starting
              of individual programs within projects.

Chapter12:     Source code for chapter 12 (various LINQ providers)
Snippy:        Source code for the "Snippy" snippet compiler
Snippets:      The snippets themselves
Databases:     Database files
Figures:       More detailed diagrams for chapter 11
OtherChapters: Code for chapters 1-11

Chapter uses multiple projects to lay out their code;
the other chapters all have a single project per chapter (or one for
VS2005/VS2008 and one for VS2008 only), and so can easily live within a
single solution.

There are two solution files in the "OtherChapters" directories,
one for Visual Studio 2005 and one for Visual Studio 2008. The Visual Studio
2008 solutions contain all projects, whereas the Visual Studio 2005 solutions
don't have any projects which require C# 3 or .NET 3.0/3.5.

In some cases the code is slightly different from that in the book, in order
to use namespaces and type names which are more appropriate for types within
a full solution.

Each project uses MiscUtil as a launcher - set a project as the startup project,
run it, and you will be presented with options of which program to run from
within that project.

Each file has been given a name reflecting its purpose; see ListingMap.txt for a map
from chapter/listing to filename.
