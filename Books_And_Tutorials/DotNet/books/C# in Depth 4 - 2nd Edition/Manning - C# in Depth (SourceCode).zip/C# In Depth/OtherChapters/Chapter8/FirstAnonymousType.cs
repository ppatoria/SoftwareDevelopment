﻿using System;
using System.ComponentModel;

namespace Chapter8
{
    [Description("Listing 8.4")]
    class FirstAnonymousType
    {
        static void Main()
        {
            var tom = new { Name = "Tom", Age = 4 };
            var holly = new { Name = "Holly", Age = 31 };
            var jon = new { Name = "Jon", Age = 31 };

            Console.WriteLine("{0} is {1} years old", jon.Name, jon.Age);
        }
    }
}
