﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Chapter8
{
    [Description("Listing 8.3")]
    class ObjectInitializer
    {
        static void Main()
        {
            Person tom = new Person
            {
                Name = "Tom",
                Age = 4,
                Home = { Town = "Reading", Country = "UK" },
                Friends = 
                {                                                  
                    new Person { Name = "Phoebe" },                
                    new Person("Abi"),                             
                    new Person { Name = "Ethan", Age = 4 },        
                    new Person("Ben")                              
                    {                                              
                        Age = 4,                                   
                        Home = { Town = "Purley", Country="UK" }   
                    }                                              
                }
            };
        }
    }
}
