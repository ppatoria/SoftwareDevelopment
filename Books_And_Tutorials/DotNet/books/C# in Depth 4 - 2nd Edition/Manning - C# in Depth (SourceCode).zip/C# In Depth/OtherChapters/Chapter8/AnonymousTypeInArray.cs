﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Chapter8
{
    [Description("Listing 8.5")]
    class AnonymousTypeInArray
    {
        static void Main()
        {
            var family = new[]                         
            {
                new { Name = "Holly", Age = 31 },      
                new { Name = "Jon", Age = 31 },        
                new { Name = "Tom", Age = 4 },         
                new { Name = "Robin", Age = 1 },       
                new { Name = "William", Age = 1 }      
            };

            int totalAge = 0;
            foreach (var person in family)
            {
                totalAge += person.Age;
            }
            Console.WriteLine("Total age: {0}", totalAge);
        }
    }
}
