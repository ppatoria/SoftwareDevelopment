using System;
using System.Collections.Generic;
using System.Text;
using MiscUtil;

namespace Chapter7
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            ApplicationChooser.Run(typeof(Program), args);
        }
    }
}
