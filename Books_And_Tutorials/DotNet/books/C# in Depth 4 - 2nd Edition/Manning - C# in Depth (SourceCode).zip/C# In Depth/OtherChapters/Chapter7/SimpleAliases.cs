using System;
using WinForms = System.Windows.Forms;
using WebForms = System.Web.UI.WebControls;
using System.ComponentModel;

namespace Chapter7
{
    [Description("Listing 7.5")]
    class SimpleAliases
    {        
        static void Main()
        {
            Console.WriteLine (typeof (WinForms.Button));
            Console.WriteLine (typeof (WebForms.Button));
        }
    }
}
