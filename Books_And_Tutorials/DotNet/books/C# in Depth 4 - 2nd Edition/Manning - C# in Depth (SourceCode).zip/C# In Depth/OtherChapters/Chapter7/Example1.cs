using System;
using System.ComponentModel;

namespace Chapter7
{
    [Description("Listing 7.1")]
    partial class Example<TFirst, TSecond>
        : IEquatable<string>
        where TFirst : class
    {
        public bool Equals(string other)
        {
            return false;
        }
    }
}