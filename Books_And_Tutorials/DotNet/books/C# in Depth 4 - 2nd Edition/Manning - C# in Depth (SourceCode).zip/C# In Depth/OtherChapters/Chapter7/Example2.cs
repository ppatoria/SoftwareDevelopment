using System;

namespace Chapter7
{
    partial class Example<TFirst, TSecond>
        : EventArgs, IDisposable
    {
        public void Dispose()
        {
        }
    }
}