using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

class Configuration {}

namespace Chapter7
{
    class Configuration {}

    [Description("Listing 7.7")]
    class GlobalNamespaceAlias
    {
        static void Main()
        {
            Console.WriteLine(typeof(Configuration));
            Console.WriteLine(typeof(global::Configuration));
            Console.WriteLine(typeof(global::Chapter7.GlobalNamespaceAlias));
        }
    }
}