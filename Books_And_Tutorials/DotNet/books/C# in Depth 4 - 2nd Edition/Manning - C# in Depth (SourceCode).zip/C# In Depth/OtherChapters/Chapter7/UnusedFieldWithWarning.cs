using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Chapter7
{
    [Description("Listing 7.9")]
    class UnusedFieldWithWarning
    {
        int x;
    }
}
