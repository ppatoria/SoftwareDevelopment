using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Chapter7
{
    [Description("Listing 7.10")]
    class UnusedWarningWithWarningSuppressed
    {
#pragma warning disable 0169
        int x;
#pragma warning restore 0169
    }
}
