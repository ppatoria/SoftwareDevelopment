using System;
using System.ComponentModel;
using WinForms = System.Windows.Forms;
using WebForms = System.Web.UI.WebControls;

namespace Chapter7
{
    [Description("Listing 7.6")]
    class DoubleColonForAliases
    {
        class WinForms
        {
        }
        
        static void Main()
        {
            Console.WriteLine (typeof (WinForms::Button));
            Console.WriteLine (typeof (WebForms::Button));
        }
    }
}
