using System;
using System.Threading;
using System.ComponentModel;

namespace Chapter5
{
    [Description("Listing 5.14")]
    class EvilEvilEvilCapturedVariables
    {
        static void Main()
        {
            ThreadStart[] delegates = new ThreadStart[2];

            int outside = 0;                                       

            for (int i=0; i < 2; i++)
            {
                int inside = 0;                                    

                delegates[i] = delegate                            
                {
                    Console.WriteLine ("({0},{1})",
                                       outside, inside);
                    outside++;
                    inside++;
                };
            }

            ThreadStart first = delegates[0];
            ThreadStart second = delegates[1];

            first();
            first();
            first();

            second();
            second();
        }
    }
}
