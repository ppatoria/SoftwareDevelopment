using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.ComponentModel;

namespace Chapter5
{
    [Description("Listing 5.3")]
    class Covariance
    {
        delegate Stream StreamFactory();

        static MemoryStream GenerateRandomData()
        {
            byte[] buffer = new byte[16];
            new Random().NextBytes(buffer);
            return new MemoryStream(buffer);
        }

        static void Main()
        {
            StreamFactory factory = GenerateRandomData;

            Stream stream = factory();
            int data;
            while ((data = stream.ReadByte()) != -1)
            {
                Console.WriteLine(data);
            }
        }
    }
}
