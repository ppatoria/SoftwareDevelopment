using System;
using System.Windows.Forms;
using System.ComponentModel;

namespace Chapter5
{
    [Description("Listing 5.9")]
    class IgnoredParametersAnonymousMethods
    {
        static void Main()
        {
            Button button = new Button();
            button.Text = "Click me";
            button.Click += delegate { Console.WriteLine("LogPlain"); };
            button.KeyPress += delegate { Console.WriteLine("LogKey"); };
            button.MouseClick += delegate { Console.WriteLine("LogMouse"); };

            Form form = new Form();
            form.AutoSize = true;
            form.Controls.Add(button);
            Application.Run(form);
        }
    }
}
