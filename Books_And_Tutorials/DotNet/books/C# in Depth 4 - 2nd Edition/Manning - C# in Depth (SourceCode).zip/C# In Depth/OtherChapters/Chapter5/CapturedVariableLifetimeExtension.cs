using System;
using System.Threading;
using System.ComponentModel;

namespace Chapter5
{
    [Description("Listing 5.12")]
    class CapturedVariableLifetimeExtension
    {
        static ThreadStart CreateDelegateInstance()
        {
            int counter = 5;

            ThreadStart ret = delegate
                {
                    Console.WriteLine(counter);
                    counter++;
                };
            ret();
            return ret;
        }

        static void Main()
        {
            ThreadStart x = CreateDelegateInstance();
            x();
            x();
        }
    }
}
