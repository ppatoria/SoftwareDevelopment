using System;
using System.Collections.Generic;
using System.Threading;
using System.ComponentModel;

namespace Chapter5
{
    [Description("Listing 5.13")]
    class MultipleCaptures
    {
        static void Main()
        {
            List<ThreadStart> list = new List<ThreadStart>();

            for (int index = 0; index < 5; index++)
            {
                int counter = index * 10;
                list.Add(delegate
                    {
                        Console.WriteLine(counter);
                        counter++;
                    }
                );
            }

            foreach (ThreadStart t in list)
            {
                t();
            }

            list[0]();
            list[0]();
            list[0]();

            list[1]();
        }
    }
}
