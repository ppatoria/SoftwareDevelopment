using System;
using System.ComponentModel;

namespace Chapter5
{
    [Description("Listing 5.7")]
    class ReturnFromAnonymousMethod
    {
        static void Main()
        {
            Predicate<int> isEven = delegate(int x)
                { return x % 2 == 0; };

            Console.WriteLine(isEven(1));
            Console.WriteLine(isEven(4));
        }
    }
}
