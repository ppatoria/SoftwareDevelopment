﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace Chapter1VS2008Only
{
    [Description("Listing 1.14")]
    class ListFilteringWithLinq
    {
        static void Main()
        {
            List<Product> products = Product.GetSampleProducts();
            var filtered = from Product p in products
                           where p.Price > 10
                           select p;
            foreach (Product product in filtered)
            {
                Console.WriteLine(product);
            }
        }
    }
}
