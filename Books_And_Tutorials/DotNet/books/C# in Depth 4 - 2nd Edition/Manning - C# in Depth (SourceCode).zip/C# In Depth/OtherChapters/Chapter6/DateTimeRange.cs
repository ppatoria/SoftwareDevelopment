using System;
using System.ComponentModel;

namespace Chapter6
{
    [Description("Listing 6.9 (part 1)")]
    public class DateTimeRange : Range<DateTime>
    {
        readonly TimeSpan step;

        public DateTimeRange(DateTime start, DateTime end)
            : this(start, end, TimeSpan.FromDays(1))
        {
        }

        public DateTimeRange(DateTime start, DateTime end,
                             TimeSpan step)
            : base(start, end)
        {
            this.step = step;
        }

        protected override DateTime GetNextValue(DateTime current)
        {
            return current + step;
        }
    }
}