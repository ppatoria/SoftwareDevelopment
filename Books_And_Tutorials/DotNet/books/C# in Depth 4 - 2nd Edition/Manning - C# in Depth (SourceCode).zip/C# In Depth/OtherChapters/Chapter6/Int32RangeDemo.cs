﻿using System;
using System.ComponentModel;

namespace Chapter6
{
    [Description("Listing 6.9 demonstration")]
    class Int32RangeDemo
    {
        static void Main()
        {
            foreach (int i in new Int32Range(0, 5))
            {
                Console.WriteLine(i);
            }
        }
    }
}
