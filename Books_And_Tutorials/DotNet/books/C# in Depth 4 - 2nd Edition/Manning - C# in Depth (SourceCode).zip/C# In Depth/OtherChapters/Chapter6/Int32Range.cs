using System;
using System.ComponentModel;

namespace Chapter6
{
    [Description("Listing 6.9 (part 2)")]
    public class Int32Range : Range<int>
    {
        readonly int step;

        public Int32Range(int start, int end)
            : this(start, end, 1)
        {
        }

        public Int32Range(int start, int end, int step)
            : base(start, end)
        {
            this.step = step;
        }

        protected override int GetNextValue(int current)
        {
            return current + step;
        }
    }
}