﻿using MiscUtil;
using System;

namespace Chapter2VS2008Only
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            ApplicationChooser.Run(typeof(Program), args); 
        }
    }
}
