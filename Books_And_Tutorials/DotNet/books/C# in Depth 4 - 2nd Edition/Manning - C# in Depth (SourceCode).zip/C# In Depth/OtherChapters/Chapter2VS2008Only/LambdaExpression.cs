﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Chapter2VS2008Only
{
    [Description("Listing 2.5")]
    class LambdaExpression
    {
        static void Main()
        {
            Func<int, int, string> func = (x, y) => (x * y).ToString();
            Console.WriteLine(func(5, 20));
        }
    }
}
