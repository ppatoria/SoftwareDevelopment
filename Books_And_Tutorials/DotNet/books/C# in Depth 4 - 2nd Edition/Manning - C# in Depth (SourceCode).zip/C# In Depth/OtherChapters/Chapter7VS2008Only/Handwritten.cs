﻿using System;

namespace Chapter7VS2008Only
{
    partial class PartialMethodDemo
    {
        partial void OnConstructorEnd()
        {
            Console.WriteLine("Manual code");
        }
    }
}
