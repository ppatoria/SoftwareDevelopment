﻿using System;
using System.ComponentModel;

namespace Chapter7VS2008Only
{
    [Description("Listing 7.2")]
    class Program
    {
        static void Main(string[] args)
        {
            new PartialMethodDemo();
            Console.ReadLine();
        }
    }
}
