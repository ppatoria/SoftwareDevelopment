﻿using System;

namespace Chapter7VS2008Only
{
    partial class PartialMethodDemo
    {
        public PartialMethodDemo()
        {
            OnConstructorStart();
            Console.WriteLine("Generated constructor");
            OnConstructorEnd();
        }

        partial void OnConstructorStart();
        partial void OnConstructorEnd();
    }
}