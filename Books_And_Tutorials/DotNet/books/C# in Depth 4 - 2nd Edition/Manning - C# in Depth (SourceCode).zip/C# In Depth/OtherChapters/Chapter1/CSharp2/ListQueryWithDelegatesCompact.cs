using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Chapter1.CSharp2
{
    [Description("Listing 1.11")]
    class ListQueryWithDelegatesCompact
    {
        static void Main()
        {
            List<Product> products = Product.GetSampleProducts();
            products.FindAll(delegate(Product p) { return p.Price > 10; })
                    .ForEach(delegate(Product p) { Console.WriteLine(p); });
        }
    }
}
