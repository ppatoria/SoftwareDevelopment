﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Chapter11.LogFile
{
    class FileLineReader : IEnumerable<string>
    {
        string file;

        public FileLineReader(string file)
        {
            this.file = file;
        }

        public IEnumerator<string> GetEnumerator()
        {
            using (TextReader reader = File.OpenText(file))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    yield return line;
                }
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
