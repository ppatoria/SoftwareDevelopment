﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Chapter11.Model;
using System.ComponentModel;

namespace Chapter11.Queries
{
    [Description("Listing 11.2")]
    class ShowAllUsersMethodCall
    {
        static void Main()
        {
            var query = SampleData.AllUsers.Select(user => user);

            foreach (var user in query)
            {
                Console.WriteLine(user);
            }
        }
    }
}
