﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Chapter11.LogFile
{
    class LogReader
    {
        static void Main()
        {
            var query = from file in Directory.GetFiles(@"C:\CSharpInDepthLogs", "*.log")
                        from line in new FileLineReader(file)
                        let entry = new LogEntry(line)
                        where entry.Type == EntryType.Error
                        select entry;

            Console.WriteLine("Total errors: {0}", query.Count());
        }
    }
}
