﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Chapter11.Model;
using System.ComponentModel;

namespace Chapter11.Queries
{
    [Description("Listing 11.1")]
    class ShowAllUsers
    {
        static void Main()
        {
            var query = from user in SampleData.AllUsers 
                        select user;

            foreach (var user in query)
            {
                Console.WriteLine(user);
            }
        }
    }
}
