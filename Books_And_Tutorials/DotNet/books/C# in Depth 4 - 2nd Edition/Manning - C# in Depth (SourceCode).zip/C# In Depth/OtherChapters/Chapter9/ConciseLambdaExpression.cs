﻿using System;
using System.ComponentModel;

namespace Chapter9
{
    [Description("Listing 9.3")]
    class ConciseLambdaExpression
    {
        static void Main()
        {
            Func<string, int> returnLength;
            returnLength = (text => text.Length);

            Console.WriteLine(returnLength("Hello"));
        }
    }
}
