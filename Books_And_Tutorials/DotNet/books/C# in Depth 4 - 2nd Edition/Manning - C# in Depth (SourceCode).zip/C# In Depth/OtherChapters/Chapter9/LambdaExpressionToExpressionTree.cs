﻿using System;
using System.ComponentModel;
using System.Linq.Expressions;

namespace Chapter9
{
    [Description("Listing 9.8")]
    class LambdaExpressionToExpressionTree
    {
        static void Main()
        {
            Expression<Func<int>> return5 = () => 5;
            Func<int> compiled = return5.Compile();
            Console.WriteLine(compiled());
        }
    }
}
