﻿using System;
using System.ComponentModel;

namespace Chapter9
{
    [Description("Listing 9.1")]
    class SimpleAnonymousMethod
    {
        static void Main()
        {
            Func<string, int> returnLength;
            returnLength = delegate(string text) { return text.Length; };

            Console.WriteLine(returnLength("Hello"));
        }
    }
}
