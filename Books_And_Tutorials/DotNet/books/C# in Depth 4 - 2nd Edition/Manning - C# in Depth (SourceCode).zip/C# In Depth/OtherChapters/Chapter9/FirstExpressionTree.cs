﻿using System;
using System.Linq.Expressions;
using System.ComponentModel;

namespace Chapter9
{
    [Description("Listing 9.6")]
    class FirstExpressionTree
    {
        static void Main()
        {
            Expression firstArg = Expression.Constant(2);
            Expression secondArg = Expression.Constant(3);
            Expression add = Expression.Add(firstArg, secondArg);

            Console.WriteLine(add);
        }
    }
}
