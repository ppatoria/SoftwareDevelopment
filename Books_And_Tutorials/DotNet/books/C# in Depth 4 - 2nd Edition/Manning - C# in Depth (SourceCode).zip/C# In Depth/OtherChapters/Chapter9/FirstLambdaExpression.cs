﻿using System;
using System.ComponentModel;

namespace Chapter9
{
    [Description("Listing 9.2")]
    class FirstLambdaExpression
    {
        static void Main()
        {
            Func<string, int> returnLength;
            returnLength = (string text) => { return text.Length; };

            Console.WriteLine(returnLength("Hello"));
        }
    }
}
