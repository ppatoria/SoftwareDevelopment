﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Chapter10
{
    [Description("Listing 10.8")]
    class RangeFiltering
    {
        static void Main()
        {
            var collection = Enumerable.Range(0, 10)
                           .Where(x => x % 2 != 0)
                           .Reverse();

            foreach (var element in collection)
            {
                Console.WriteLine(element);
            }
        }
    }
}
