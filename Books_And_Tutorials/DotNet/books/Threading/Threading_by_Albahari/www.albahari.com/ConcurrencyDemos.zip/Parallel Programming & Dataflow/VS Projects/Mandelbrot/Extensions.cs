﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

public static class Extensions
{
	public static IEnumerable<Rect> Interpolate (this IEnumerable<Rect> source, int frames)
	{
		Rect previous = source.First ();
		foreach (Rect next in source.Skip (1))
		{
			yield return previous;
			double leftDelta = (next.Left - previous.Left) / frames;
			double rightDelta = (next.Right - previous.Right) / frames;
			double topDelta = (next.Top - previous.Top) / frames;
			double bottomDelta = (next.Bottom - previous.Bottom) / frames;

			for (int i = 0; i < frames - 1; i++)
			{
				previous.X += leftDelta;
				previous.Y += topDelta;
				previous.Width += rightDelta - leftDelta;
				previous.Height += bottomDelta - topDelta;
				yield return previous;
			}
			previous = next;
		}
	}
}
