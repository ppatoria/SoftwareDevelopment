﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Threading;
using System.Threading.Tasks;
using System.IO;

namespace Mandelbrot
{
	public class Frame
	{
		public readonly Rect SetBounds;
		public readonly int RenderWidth, RenderHeight;

		uint [] _pixels;
		
		public Frame (Rect setBounds, int renderWidth, int renderHeight,
			bool renderNow = false)
		{
			SetBounds = setBounds;
			RenderWidth = renderWidth;
			RenderHeight = renderHeight;

			_pixels = new uint [renderWidth * renderHeight];

			if (renderNow) Render ();
		}

		public void Render ()
		{
			int maxCycles = 500;
			if (SetBounds.Width < 1) maxCycles = Convert.ToInt32 (Math.Log10 (1 / SetBounds.Width) * 5000);

			Action<int> lineCalculator = yPixel =>
			{
				double y = SetBounds.Height * yPixel / RenderHeight + SetBounds.Y;
				for (int xPixel = 0; xPixel < RenderWidth; xPixel++)
				{
					double x = SetBounds.Width * xPixel / RenderWidth + SetBounds.X;
					_pixels [xPixel + yPixel * RenderWidth] = CalculateColor (x, y, maxCycles);
				}
			};

			//for (int i = 0; i < RenderHeight; i++) lineCalculator (i);
			Parallel.For (0, RenderHeight, lineCalculator);
		}

		static uint CalculateColor (double x, double y, int maxCycles)
		{
			int iteration = 0;
			double xx = x, yy = y;
			while (xx * xx + yy * yy <= 4)
			{
				if (iteration++ > maxCycles) return 0xFF000000;
				double temp = xx * xx - yy * yy + x;
				yy = 2 * xx * yy + y;
				xx = temp;
			}

			return (uint)(_colors [iteration % _colors.Length] + 0xFF000000);
		}

		public unsafe System.Drawing.Image GetImage ()
		{
			fixed (void* b = _pixels)
			{
				var ptr = new IntPtr (b);
				return new System.Drawing.Bitmap (RenderWidth, RenderHeight, 4 * RenderWidth,
					System.Drawing.Imaging.PixelFormat.Format32bppArgb, ptr);
			}
		}

		public BitmapSource GetBitmapSource ()
		{
			const int DPI = 96;

			return BitmapSource.Create (
				RenderWidth, RenderHeight,
				DPI, DPI,
				PixelFormats.Bgra32,
				null, _pixels,
				RenderWidth * 4);
		}	

		public MemoryStream EncodeToPng ()
		{
			MemoryStream ms = new MemoryStream ();
			BitmapSource bmpSource = GetBitmapSource ();
			var encoder = new PngBitmapEncoder ();
			encoder.Frames.Add (BitmapFrame.Create (bmpSource));
			encoder.Save (ms);
			ms.Position = 0;
			return ms;
		}

		public Rect GetZoomRect (int centrePixelX, int centrePixelY)
		{
			double centreSetX = SetBounds.Width * centrePixelX / RenderWidth + SetBounds.X;
			double centreSetY = SetBounds.Height * centrePixelY / RenderHeight + SetBounds.Y;

			double newWidth = SetBounds.Width / 4;
			double newHeight = newWidth * RenderHeight / RenderWidth;

			return new System.Windows.Rect (
				centreSetX - newWidth / 2,
				centreSetY - newHeight / 2,
				newWidth, newHeight);
		}

		public IEnumerable<Rect> GetZoomRects (int centrePixelX, int centrePixelY, 
			int intermediateFrames)
		{
			Rect previous = SetBounds;
			Rect next = GetZoomRect (centrePixelX, centrePixelY);

			double leftDelta = (next.Left - previous.Left) / intermediateFrames;
			double rightDelta = (next.Right - previous.Right) / intermediateFrames;
			double topDelta = (next.Top - previous.Top) / intermediateFrames;
			double bottomDelta = (next.Bottom - previous.Bottom) / intermediateFrames;

			for (int i = 0; i < intermediateFrames - 1; i++)
			{
				previous.X += leftDelta;
				previous.Y += topDelta;
				previous.Width += rightDelta - leftDelta;
				previous.Height += bottomDelta - topDelta;
				yield return previous;
			}
			previous = next;
		}

		static int [] _colors =
			Enumerable.Range (0, 6).Select (i => i * 20 + 135).Concat (
			Enumerable.Range (0, 8).Select (i => (i * 30 + 10) * 256 + (7 - i) * 10 + 155)).Concat (
			Enumerable.Range (0, 6).Select (i => ((5 - i) * 30 + 90) * 256)).Concat (
			Enumerable.Range (0, 4).Select (i => ((3 - i) * 30) * 256 + i * 40))
			.ToArray ();
	}
}
