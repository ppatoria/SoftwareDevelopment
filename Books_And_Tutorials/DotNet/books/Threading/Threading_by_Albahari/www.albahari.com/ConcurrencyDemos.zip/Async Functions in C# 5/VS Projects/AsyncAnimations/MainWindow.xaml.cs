﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading.Tasks;

namespace AsyncAnimations
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow ()
		{
			InitializeComponent ();
			this.Loaded += delegate 
			{
				AnimateHello ();
				AnimateWorld ();
			};
		}

		async void AnimateHello ()
		{
			while (true)
				for (double x = 0; x < canvas.ActualWidth; x += 5)
				{
					txtHello.SetValue (Canvas.LeftProperty, x);
					await TaskEx.Delay (20);
				}
		}

		async void AnimateWorld ()
		{
			while (true)
				for (double y = 0; y < canvas.ActualHeight; y += 10)
				{
					txtWorld.SetValue (Canvas.TopProperty, y);
					await TaskEx.Delay (20);
				}
		}
	}
}
