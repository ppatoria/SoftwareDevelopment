﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Threading.Tasks;
using System.Threading;

namespace Web_Page_Intro
{
	public partial class MainWindow : Window
	{
		string[] _uris =
		{
			"http://linqpad.net",
			"http://linqpad.net/downloadglyph.png",
			"http://linqpad.net/linqpadscreen.png",
			"http://linqpad.net/linqpadmed.png",
		};

		public MainWindow()
		{
			InitializeComponent();
		}

		void btnGo_Click(object sender, RoutedEventArgs e)
		{
			PopulateAsync();
		}

		void PopulateSync()
		{
			listView.Items.Clear();
			btnGo.IsEnabled = false;
			try
			{
				int totalLength = 0;
				foreach (string uri in _uris)
				{
					string html = new WebClient().DownloadString(new Uri(uri));
					totalLength += html.Length;
					listView.Items.Add(new PageLength(uri, uri.Length));
				}
				txtResult.Text = "TOTAL LENGTH: " + totalLength.ToString("N0");
			}
			catch (Exception ex)
			{
				txtResult.Text = "ERROR: " + ex.Message;
			}
			finally
			{
				btnGo.IsEnabled = true;
			}
		}

		async void PopulateAsync()
		{
			listView.Items.Clear();
			btnGo.IsEnabled = false;
			btnCancel.IsEnabled = true;
			try
			{
				int totalLength = 0;
				foreach (string uri in _uris)
				{
					string html = await new WebClient().DownloadStringTaskAsync(new Uri(uri), _cancelSource.Token);
					totalLength += html.Length;
					listView.Items.Add(new PageLength(uri, uri.Length));
				}
				txtResult.Text = "TOTAL LENGTH: " + totalLength.ToString("N0");
			}
			catch (Exception ex)
			{
				txtResult.Text = "ERROR: " + ex.Message;
			}
			finally
			{
				btnGo.IsEnabled = true;
				btnCancel.IsEnabled = false;
			}
		}

		async void PopulateAsyncWithProgress()
		{
			listView.Items.Clear();
			btnGo.IsEnabled = false;
			btnCancel.IsEnabled = true;
			progressBar.Visibility = System.Windows.Visibility.Visible;
			try
			{
				int totalLength = 0;
				foreach (string uri in _uris)
				{
					var progress = new Progress<DownloadProgressChangedEventArgs>(p => progressBar.Value = p.ProgressPercentage);
					string html = await new WebClient().DownloadStringTaskAsync (new Uri(uri), _cancelSource.Token, progress);
					totalLength += html.Length;
					listView.Items.Add(new PageLength(uri, uri.Length));
				}
				txtResult.Text = "TOTAL LENGTH: " + totalLength.ToString("N0");
			}
			catch (Exception ex)
			{
				txtResult.Text = "ERROR: " + ex.Message;
			}
			finally
			{
				btnGo.IsEnabled = true;
				btnCancel.IsEnabled = false;
				progressBar.Visibility = System.Windows.Visibility.Collapsed;
			}
		}

		#region Speakerphone!

		void PopulateOnWorkerThread()
		{
			listView.Items.Clear();
			btnGo.IsEnabled = false;
			new Thread(PopulateWorker) { IsBackground = true }.Start();
		}

		void PopulateWorker()
		{
			try
			{
				int totalLength = 0;
				foreach (string uri in _uris)
				{
					string html = new WebClient().DownloadString(new Uri(uri));
					totalLength += html.Length;
					Dispatcher.BeginInvoke(new Action(() =>
						listView.Items.Add(new PageLength(uri, html.Length))
						));
				}
				Dispatcher.BeginInvoke(new Action(() =>
					txtResult.Text = "TOTAL LENGTH: " + totalLength.ToString("N0")
					));
			}
			catch (Exception ex)
			{
				Dispatcher.BeginInvoke(new Action(() =>
					txtResult.Text = "ERROR: " + ex.Message
					));
			}
			finally
			{
				Dispatcher.BeginInvoke(new Action(() => btnGo.IsEnabled = true));
			}
		}

		#endregion

		#region Cancellation

		CancellationTokenSource _cancelSource = new CancellationTokenSource();

		void btnCancel_Click(object sender, RoutedEventArgs e)
		{
			_cancelSource.Cancel();
			_cancelSource = new CancellationTokenSource();
		}

		#endregion

		#region Workaround for APM's lack of asynchronony in resolving DNS & Proxies

		public Task<string> DownloadStringTrulyAsync (Uri address,
			CancellationToken cancelToken = default(CancellationToken),
			IProgress<DownloadProgressChangedEventArgs> progress = null)
		{
			// Start the download operation on a pooled thread. This will block a pooled thread - but only for
			// the (hopefully brief) period of time when the underlying APM methods inappropriately block.
			return TaskEx.RunEx (() => new WebClient().DownloadStringTaskAsync (address, cancelToken, progress));
		}

		#endregion
	}
}
