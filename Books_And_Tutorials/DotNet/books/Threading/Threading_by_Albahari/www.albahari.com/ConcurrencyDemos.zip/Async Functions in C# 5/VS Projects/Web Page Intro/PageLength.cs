﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Web_Page_Intro
{
	class PageLength
	{
		public string Page { get; private set; }
		public int Length { get; private set; }

		public PageLength (string page, int length)
		{
			Page = page;
			Length = length;
		}
	}
}
