﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Net;

namespace Web_Page_Intro
{
	class WebSizeCalculatorTap
	{
		public static async Task<int> GetWebPageSizeAsync (string [] uris,
			CancellationToken cancelToken = default (CancellationToken))
		{
			int totalLength = 0;

			foreach (string uri in uris)
			{
				string html = await new WebClient ().DownloadStringTaskAsync (new Uri (uri), cancelToken);
				totalLength += html.Length;
			}
			return totalLength;
		}
	}
}




