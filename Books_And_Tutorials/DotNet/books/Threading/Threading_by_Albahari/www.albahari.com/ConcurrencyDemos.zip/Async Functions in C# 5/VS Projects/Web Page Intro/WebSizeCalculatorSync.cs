﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Net;

namespace Web_Page_Intro
{
	class WebSizeCalculatorSync
	{
		public static int GetWebPageSize (string [] uris)
		{

			int totalLength = 0;

			foreach (string uri in uris)
			{
				string html = new WebClient ().DownloadString (new Uri (uri));
				totalLength += html.Length;
			}
			return totalLength;
		}
	}
}
