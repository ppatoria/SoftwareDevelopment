﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Net;

namespace Web_Page_Intro
{
	class WebSizeCalculatorTapWithProgress
	{
		public static async Task<int> GetWebPageSizeAsync (string [] uris,
			CancellationToken cancelToken = default (CancellationToken),
			IProgress<int> percentProgress = null,
			IProgress<PageLength> pageProgress = null)		// My cheeky extension to the TAP
		{
			int totalLength = 0, pageIndex = 0;

			var webProgress = percentProgress == null ? null :
				new Progress<DownloadProgressChangedEventArgs> (args =>
					percentProgress.Report ((pageIndex * 100 + args.ProgressPercentage) / uris.Length));

			foreach (string uri in uris)
			{
				string html = await new WebClient ().DownloadStringTaskAsync (
					new Uri (uri), cancelToken, webProgress);

				if (pageProgress != null) pageProgress.Report (new PageLength (uri, html.Length));
				totalLength += html.Length;
				pageIndex++;
			}
			return totalLength;
		}
	}
}
