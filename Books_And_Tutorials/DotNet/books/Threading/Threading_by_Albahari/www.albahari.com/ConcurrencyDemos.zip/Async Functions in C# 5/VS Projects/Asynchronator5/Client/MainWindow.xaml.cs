﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Threading;

namespace AsyncClient
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		CancellationTokenSource _cancelSource;
		Progress<bool> _progress;
		int _throughput;

		public MainWindow ()
		{
			InitializeComponent ();
			Left = 200;
			Top = 50;

			_progress = new Progress<bool> (p => 
			{
				txtStatus.Background = p ? Brushes.PaleGreen : Brushes.Pink;
				txtStatus.Text = p ? "OK" : "Error";
				if (p) _throughput++;
			});

			Loaded += delegate { UpdateThroughput (); };
		}

		async void UpdateThroughput ()
		{
			while (IsLoaded)
			{
				whiteout.Height = guageContainer.ActualHeight - Math.Min (1200, _throughput) * guageContainer.ActualHeight / 1200;
				txtCount.Text = _throughput.ToString ();
				_throughput = 0;
				await TaskEx.Delay (1000);
			}
		}

		void btnStart_Click (object sender, RoutedEventArgs e)
		{
			btnStart.IsEnabled = false;
			btnStop.IsEnabled = true;

			_cancelSource = new CancellationTokenSource ();
			ClientSimulator.Start (_cancelSource.Token, _progress);
		}

		void btnStop_Click (object sender, RoutedEventArgs e)
		{
			btnStart.IsEnabled = true;
			btnStop.IsEnabled = false;

			_cancelSource.Cancel ();
			_cancelSource = null;
		}

		protected override void OnClosed (EventArgs e)
		{
			if (_cancelSource != null) _cancelSource.Cancel ();
			base.OnClosed (e);
		}
	}
}
