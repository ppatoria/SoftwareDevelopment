﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Windows;

namespace Asynchronator5
{
	abstract class Server
	{
		CancellationTokenSource _cancelSource;
		volatile bool _running;

		public void Start ()
		{
			_cancelSource = new CancellationTokenSource ();

			var listener = new TcpListener (IPAddress.Any, 51111);
			listener.Start ();
			
			_running = true;

			new Thread (() =>
			{
				try
				{
					Start (listener, _cancelSource.Token);
					Thread.Sleep (1500);
					listener.Stop ();
				}
				catch (Exception ex)
				{
					if (_running) MessageBox.Show (ex.Message);
				}
			})
			{ IsBackground = true } .Start ();
		}

		public void Stop ()
		{
			_cancelSource.Cancel ();
			_running = false;
		}

		public abstract void Start (TcpListener listener, CancellationToken cancelToken);
	}
}
