﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;
using System.Net;

namespace Web_Page_Intro
{
	class WebSizeCalculatorEap
	{
		object _locker = new object ();
		SynchronizationContext _syncContext;
		string [] _uris;
		int _currentPageIndex, _totalLength;
		bool _canceled;
		WebClient _currentWebClient;

		public event EventHandler<GetSiteSizeCompletedEventArgs> GetSiteSizeCompleted;
		public event EventHandler<GetSiteSizeProgressEventArgs> GetSiteSizeProgressChanged;	

		public void GetSiteSizeAsync (string [] uris)
		{
			_uris = uris;
			_syncContext = SynchronizationContext.Current;
			FetchPage ();
		}

		public void CancelAsync ()
		{
			lock (_locker)
			{
				_canceled = true;
				if (_currentWebClient != null) _currentWebClient.CancelAsync ();
			}
		}

		void FetchPage ()
		{
			lock (_locker)
			{
				if (_canceled)
				{
					OnGetSiteSizeCompleted (0, null, true);
					return;
				}
				_currentWebClient = new WebClient ();
				_currentWebClient.DownloadStringCompleted += PageDownloadCompleted;
			}
			try
			{
				_currentWebClient.DownloadStringAsync (new Uri (_uris [_currentPageIndex]));
			}
			catch (Exception ex)
			{
				OnGetSiteSizeCompleted (0, ex, false);
			}
		}

		void PageDownloadCompleted (object sender, DownloadStringCompletedEventArgs downloadArgs)
		{
			if (downloadArgs.Error != null || downloadArgs.Cancelled)
			{
				OnGetSiteSizeCompleted (0, downloadArgs.Error, downloadArgs.Cancelled);
				return;
			}

			_totalLength += downloadArgs.Result.Length;

			OnGetSiteSizeProgressChanged (
				(_currentPageIndex + 1) * 100 / _uris.Length,
				_uris[_currentPageIndex],
				downloadArgs.Result.Length);

			if (++_currentPageIndex < _uris.Length)
			{
				FetchPage ();
				return;
			}

			OnGetSiteSizeCompleted (_totalLength, null, false);
		}

		void OnGetSiteSizeProgressChanged (int percent, string uri, int uriLength)
		{
			if (GetSiteSizeProgressChanged == null) return;

			Action action = () =>
				GetSiteSizeProgressChanged (this, new GetSiteSizeProgressEventArgs (percent, uri, uriLength));

			if (_syncContext == null)
				action ();
			else
				_syncContext.Post (_ => action (), null);
		}		

		void OnGetSiteSizeCompleted (int result, Exception exception, bool cancelled)
		{
			if (GetSiteSizeCompleted == null) return;

			Action action = () =>
				GetSiteSizeCompleted (this, new GetSiteSizeCompletedEventArgs (result, exception, cancelled));

			if (_syncContext == null)
				action ();
			else
				_syncContext.Post (_ => action (), null);
		}	
	}

	public class GetSiteSizeCompletedEventArgs : AsyncCompletedEventArgs
	{
		public int Result { get; private set; }

		internal GetSiteSizeCompletedEventArgs (int result, Exception exception, bool cancelled)
			: base (exception, cancelled, null)
		{
			Result = result;
		}
	}

	public class GetSiteSizeProgressEventArgs : ProgressChangedEventArgs
	{
		public string Uri{ get; private set; }
		public int UriLength { get; private set; }

		internal GetSiteSizeProgressEventArgs (int progressPercentage, string uri, int uriLength)
			: base (progressPercentage, null)
		{
			Uri = uri;
			UriLength = uriLength;
		}
	}
}