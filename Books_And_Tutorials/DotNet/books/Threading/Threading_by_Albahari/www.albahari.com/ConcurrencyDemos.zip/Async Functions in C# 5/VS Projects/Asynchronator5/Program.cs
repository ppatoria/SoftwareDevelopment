﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Threading;

namespace Asynchronator5
{
	class Program
	{
		[STAThread]
		static void Main ()
		{
			ThreadPool.SetMinThreads (1100, 1100);
			ThreadPool.SetMaxThreads (1100, 1100);

			new Application ().Run (new MainWindow ());
		}
	}
}
