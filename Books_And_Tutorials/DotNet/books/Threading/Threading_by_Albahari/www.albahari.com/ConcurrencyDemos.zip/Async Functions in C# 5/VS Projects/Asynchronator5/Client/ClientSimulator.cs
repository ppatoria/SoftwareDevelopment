﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncClient
{
	class ClientSimulator
	{
		public const string HostName = "127.0.0.1";
		public const int TcpPort = 51111;
		public const int MessageLength = 5000;

		public static void Start (CancellationToken cancelToken, IProgress<bool> progress)
		{
			TaskEx.Run (() =>
			{
				for (int i = 0; i < 1000; i++)
					MakeRequests (true, cancelToken, progress);
			});
		}

		public static async Task MakeRequests (bool slow, CancellationToken cancelToken, IProgress<bool> progress)
		{
			while (!cancelToken.IsCancellationRequested)
			{
				try
				{
					await MakeRequest (cancelToken);
					progress.Report (true);
					continue;
				}
				catch (Exception)
				{
					progress.Report (false);
				}
				await TaskEx.Delay (100);
			}
		}

		public static async Task MakeRequest (CancellationToken cancelToken)
		{
			byte [] toSend = new byte [MessageLength];
			byte [] reply = new byte [MessageLength];

			new Random ().NextBytes (toSend);		// Random message to send

			using (var client = new TcpClient ())
			{
				await client.ConnectAsync (HostName, TcpPort);
				using (Stream s = client.GetStream ())
					for (int i = 0; i < 5; i++)
					{
						await TaskEx.Delay (80);
						cancelToken.ThrowIfCancellationRequested ();

						await s.WriteAsync (toSend, 0, toSend.Length);

						await TaskEx.Delay (80);
						cancelToken.ThrowIfCancellationRequested ();

						int bytesRead = 0, chunkSize = 1;                    // Read reply from server
						while (bytesRead < reply.Length && chunkSize > 0)
							bytesRead +=
							  chunkSize = await s.ReadAsync (reply, bytesRead, reply.Length - bytesRead);

						// Check that we've got a valid message back. All the bytes should be reversed.
						if (!toSend.SequenceEqual (reply.Reverse()))
							throw new Exception ("Invalid reply at index " + i);
					}
			}		
		}
	}
}

