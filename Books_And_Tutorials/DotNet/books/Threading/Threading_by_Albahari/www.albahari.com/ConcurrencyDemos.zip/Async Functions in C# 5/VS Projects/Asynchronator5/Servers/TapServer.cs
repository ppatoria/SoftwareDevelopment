﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace Asynchronator5.Servers
{
	class TapServer : Server
	{
		public override void Start (TcpListener listener, CancellationToken cancelToken)
		{
			while (!cancelToken.IsCancellationRequested)
			{
				TcpClient c = listener.AcceptTcpClient ();
				TaskEx.Run (() => Accept (c));
			}
		}

		async Task Accept (TcpClient client)
		{
			try
			{
				using (client)
				using (NetworkStream n = client.GetStream ())
					for (int i = 0; i < 5; i++)
					{
						byte [] data = new byte [5000];

						int bytesRead = 0; int chunkSize = 1;
						while (bytesRead < data.Length && chunkSize > 0)
							bytesRead += chunkSize =
								await n.ReadAsync (data, bytesRead, data.Length - bytesRead);

						Array.Reverse (data);
						await n.WriteAsync (data, 0, data.Length);
					}
			}
			catch (Exception ex) { Console.WriteLine (ex.Message); }
		}
	}
}
