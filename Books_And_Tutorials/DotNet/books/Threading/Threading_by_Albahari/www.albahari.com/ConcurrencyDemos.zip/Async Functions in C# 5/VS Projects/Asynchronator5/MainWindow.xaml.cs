﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using Asynchronator5.Servers;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Asynchronator5
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		Server _currentServer;

		public MainWindow ()
		{
			InitializeComponent ();
			Left = 450;
			Top = 50;
			Loaded += delegate { RunThreadMonitor (); };
		}

		protected override void OnClosed (EventArgs e)
		{
			if (_currentServer != null) _currentServer.Stop ();
		}

		void btnStart_Click (object sender, RoutedEventArgs e)
		{
			btnStart.IsEnabled = false;
			btnStop.IsEnabled = true;

			_currentServer = GetServer ();

			try { _currentServer.Start (); }
			catch (Exception ex) { MessageBox.Show (ex.Message); }
		}

		void btnStop_Click (object sender, RoutedEventArgs e)
		{
			btnStart.IsEnabled = true;
			btnStop.IsEnabled = false;

			_currentServer.Stop ();
			_currentServer = null;
		}

		Server GetServer ()
		{
			if (rbBlocking.IsChecked.Value)
				return new BlockingServer ();
			else if (rbAPM.IsChecked.Value)
				return new ApmServer ();
			else if (rbAPMExtensible.IsChecked.Value)
				return new ExtensibleApmServer ();
			else
				return new TapServer ();
		}

		#region Thread Monitor

		async void RunThreadMonitor ()
		{
			while (true)
			{
				int threadCount = GetThreadCount ();
				whiteout.Height = guageContainer.ActualHeight - Math.Min (1200, threadCount) * guageContainer.ActualHeight / 1200;
				txtThreadCount.Text = threadCount.ToString ();				
				if (!await this.Delay (100)) return;
			}
		}

		int GetThreadCount ()
		{
			using (Process p = Process.GetCurrentProcess ())
				return p.Threads.Count;
			
		}
		#endregion
	}

	static class Extensions
	{
		public static Task<bool> Delay (this Window window, int ms)
		{
			var scheduler = TaskScheduler.FromCurrentSynchronizationContext();
			var tcs = new TaskCompletionSource<bool> ();
			EventHandler handler = null;
			handler = delegate
			{
				if (tcs.TrySetResult (false))
					window.Closed -= handler;
			};
			window.Closed += handler;
			TaskEx.Delay (ms).ContinueWith (ant =>
			{
				if (tcs.TrySetResult (true))
					window.Closed -= handler;
			}, scheduler);
			return tcs.Task;
		}
	}
}
