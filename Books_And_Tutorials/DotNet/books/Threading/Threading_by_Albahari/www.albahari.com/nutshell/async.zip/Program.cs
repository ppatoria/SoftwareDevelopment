﻿using System;
using System.Net;
using System.Threading;
using System.Reflection;
using System.Diagnostics;

/* ASYNCHRONOUS METHODS DEMO
 *
 * This project demonstrates how to use and write asynchronous methods, in the context of a 
 * simple TCP server application.
 * 
 * The server continually listens for client connections. When it receives a connection, it
 * reads 5000 bytes, reverses the bytes, and sends the result back to the client.
 * 
 * There are three implementations of the server:
 * 
 *   1. Blocking/Server               - uses synchronous (blocking) networking methods
 *   2. Nonblocking/Server            - uses asynchronous (non-blocking) networking methods
 *   3. ExtensibleNonblocking/Server  - demonstrates how to *write* asynchronous methods
 *   
 * To switch between each of the three servers, edit the StartServer() method.
 * 
 * The main method does two things:
 *  - it starts the TCP server;
 *  - it starts, in a separate process, a method that simulates 60 clients connecting
 *    to the server at once.
 * 
 * The first fifty clients simulate a SLOW TCP connection.
 * The remaining ten clients simulate a FAST TCP connection.
 *
 * When a slow client finishes, it writes 'S' to the Console.
 * When a fast client finishes, it writes 'F' to the Console.
 * 
 * Ideally, the fast 10 should finish almost immediately and the slow 50 should finish a few
 * seconds later. This is indeed what happens when you use either of the non-blocking servers.
 * 
 * With the blocking server, however, the 50 slow clients hog the thread pool, resulting 
 * in the 10 fast clients finishing at around the same time as the slow clients. 
 * 
 */

namespace AsynchronousMethods
{
  class Program
  {
    public const int TcpPort = 51111;
    public const int MessageLength = 5000;

    static void Main (string [] args)
    {
      if (args.Length > 0 && args [0] == "client")
      {
        SimulateClients ();
        return;
      }

      // Start the TCP server on a separate thread
      Thread t = new Thread (StartServer);
      t.IsBackground = true;
      t.Start ();

      Thread.Sleep (200);       // Give server has time to come online

      // Launch a separate process to simulate clients
      Process.Start (Assembly.GetExecutingAssembly ().CodeBase, "client");

      Console.WriteLine ("Server started: press Enter to exit");
      Console.ReadLine ();
    }

    static void StartServer ()
    {
      // Uncomment one of the lines below:

      new Blocking.Server ().Serve (IPAddress.Any, TcpPort);
      //new Nonblocking.Server ().Serve (IPAddress.Any, TcpPort);
      //new ExtensibleNonblocking.Server ().Serve (IPAddress.Any, TcpPort);
    }

    static void SimulateClients ()
    {
      Console.WriteLine ("Running clients...");

      // Start 50 slow clients...
      for (int i = 0; i < 50; i++)
        new Thread (SimulateClient).Start (true);

      Thread.Sleep (100);

      // ...followed by 10 fast clients
      for (int i = 0; i < 10; i++)
        new Thread (SimulateClient).Start (false);

      Console.ReadLine ();
    }

    static void SimulateClient (object slow)
    {
      Client.Test ((bool)slow, "localhost", TcpPort);
    }
  }
}
