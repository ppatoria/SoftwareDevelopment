#ifndef TEST_H
#define TEST_H
#include <iostream>

using namespace std;

class Test
{
    public:
        Test();
        Test(int i);
    friend ostream& operator<<(ostream& os, Test& test);
    protected:
    private:
        int i_;
};

#endif // TEST_H
