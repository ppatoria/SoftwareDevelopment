//#include "Test.h"
#include "C:\Users\Pralay\Documents\C++Projects\TestProject\include\Test.h"

Test::Test()
{
    //ctor
}

Test::Test(int i)
{
    i_ = i;
}

ostream& operator<<(ostream& os, Test& t)
{
    os << t.i_;
    return os;
}

