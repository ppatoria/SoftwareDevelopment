#include <iostream>
#include "C:\Users\Pralay\Documents\C++Projects\TestProject\include\Test.h"
using namespace std;

class Base{
    private:
        int a,b,c;
        Base& operator=(const Base& rhs)
        {
        }
    public:
        Base(){}
        Base(int x, int y, int z)
        {
            a=x;
            b=x;
            c=z;
        }
        int XYZ()
        {
         return a*b*c;
        }
};

class Derived : public Base{
    public:
    Derived(){}
    Derived(int a, int b, int c)//: Base(a,b,c)
    {
    }
};
int main()
{
    Derived d(10,20,30);
    Derived dd(40,20,30);
    cout << d.XYZ();
    d = dd;

    cout << "Hello world!" << endl;
    Test* t = new Test(10);
    cout << t;
    return 0;
}
