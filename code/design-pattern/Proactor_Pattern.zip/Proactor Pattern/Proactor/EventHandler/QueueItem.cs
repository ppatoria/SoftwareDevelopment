#region License
/* Copyright (c) 2008 Hamed Ebrahimmalek
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy 
 * of this software and associated documentation files (the "Software"), to 
 * deal in the Software without restriction, including without limitation the 
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or 
 * sell copies of the Software, and to permit persons to whom the Software is 
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in 
 * all copies or substantial portions of the Software. 
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
 * THE SOFTWARE.
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Operational.Interfaces;

namespace EventHandler
{
    #region Copyright Hamed Ebrahimmalek, 2008
    // Hamed Ebrahimmalek
    //
    // Project              : Proactor
    // Module               : EventHandler
    // File name            : QueueItem.cs
    // Revision             : 0.1
    // Creation Date        : 28-04-2008
    // First Author         : Hamed Ebrahimmalek
    //
    // Description          : 
    //
    #endregion

    /// <summary>
    /// This class is responsible for holding the data for every 
    /// enqueue of the dispatcher.
    /// </summary>
    public class QueueItem
    {
        /// <summary>
        /// The dispatchable item to hold for dispatching
        /// </summary>
        IDispatchable _dispItem = null;

        /// <summary>
        /// the event for the dispatchable item to dispatch
        /// </summary>
        IEvent _ievent = null;

        /// <summary>
        /// Overloaded constructor
        /// </summary>
        /// <param name="dispItem">the dispatchable item</param>
        /// <param name="ievent">the event which is requested to enqueue</param>
        public QueueItem( IDispatchable dispItem, IEvent ievent )
        {
            _dispItem = dispItem;
            _ievent = ievent;
        }
        /// <summary>
        /// private constructor, no default constructor allowed!
        /// </summary>
        private QueueItem( )
        {

        }

        /// <summary>
        /// Property to get the dispatchable
        /// </summary>
        public IDispatchable DISP_ITEM
        {
            get { return _dispItem; }
        }
        
        /// <summary>
        /// property to get the IEvent
        /// </summary>
        public IEvent IEVENT
        {
            get { return _ievent; }
        }

    }
}
