#region License
/* Copyright (c) 2008 Hamed Ebrahimmalek
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy 
 * of this software and associated documentation files (the "Software"), to 
 * deal in the Software without restriction, including without limitation the 
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or 
 * sell copies of the Software, and to permit persons to whom the Software is 
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in 
 * all copies or substantial portions of the Software. 
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
 * THE SOFTWARE.
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Diagnostics;

namespace EventHandler
{
    #region Copyright Hamed Ebrahimmalek, 2008
    // Hamed Ebrahimmalek
    //
    // Project              : Proactor
    // Module               : EventHandler
    // File name            : PriorityQueue.cs
    // Revision             : 0.1
    // Creation Date        : 28-04-2008
    // First Author         : Hamed Ebrahimmalek
    //
    // Description          : 
    //
    #endregion

    public sealed class PriorityQueue
    {
        /// <summary>
        /// The priority queues
        /// </summary>
        private Queue[] _priorityQueues = null;

        /// <summary>
        /// Use this class to enqueue your objects with priority. The object with 
        /// a higher priority will be dequeued first.
        /// </summary>
        /// <param name="numberOfPriorities">The number of priorities</param>
        public PriorityQueue(UInt32 numberOfPriorities)
        {
            Debug.Assert(numberOfPriorities != 0);

            // declare the queues
            _priorityQueues = new Queue[numberOfPriorities];

            // initialize the queues
            for (UInt32 i = 0; i < numberOfPriorities; i++)
            {
                _priorityQueues[i] = new Queue();
            }
        }

        /// <summary>
        /// No private constructor allowed
        /// </summary>
        private PriorityQueue()
        {

        }

        /// <summary>
        /// This method will dequeue the object with a higher priority firts.
        /// 0 is the highest priority 
        /// </summary>
        /// <returns>the object with the highest priority</returns>
        public object Dequeue()
        {
            int counter = 0;
            object foundItem = null;

            do
            {
                if (_priorityQueues[counter].Count > 0)
                {
                    foundItem = _priorityQueues[counter].Dequeue();
                }
                counter++;
            }
            while (counter < _priorityQueues.Length && foundItem == null);

            return foundItem;
        }

        /// <summary>
        /// This method will enqueue the object with the given priority.
        /// 0 is the highest priority
        /// </summary>
        /// <param name="queueItem">the item to enqueue</param>
        /// <param name="priority"></param>
        public void Enqueue(object queueItem, UInt32 priority)
        {
            _priorityQueues[priority].Enqueue(queueItem);
        }

        /// <summary>
        /// The number of items within all of the available queues
        /// </summary>
        public int Count
        {
            get
            {
                int count = 0;
                for (UInt32 i = 0; i < _priorityQueues.Length; i++)
                {
                    count += _priorityQueues[i].Count;
                }
                return count;
            }
        }

        /// <summary>
        /// This method will return the number of priority queues
        /// </summary>
        public int NumberOfPriorities
        {
            get { return _priorityQueues.Length; }
        }

        /// <summary>
        /// This method will return the number of items within the requested priority queue
        /// </summary>
        /// <param name="priority">the priority queue</param>
        /// <returns>the number of items within the given priority queue</returns>
        public int CountOfPriority(UInt32 priority)
        {
            Debug.Assert(priority > _priorityQueues.Length, "You have requested size of a priority which does not exists!" );
            return _priorityQueues[priority].Count;
        }
    }
}
