using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EventHandler;
using Logic;
using Events;

namespace Asynchronous_Dispatcher
{
    public partial class Form1 : Form
    {
        private Bird _hawk = null;
        private Bird _eagle = null;
        private uint _numberOfEventsToCreate = 1000000;

        public Form1()
        {
            InitializeComponent();         
            InitializeDispatcher();
            InitializeDispatchable();
            DispatchEvents();
        }

        private void InitializeDispatcher()
        {
            Dispatcher.GetInstance.Initialize();
            Dispatcher.GetInstance.Start( );
        }

        private void TerminateDispatcher()
        {
            Dispatcher.GetInstance.Stop();
            Dispatcher.GetInstance.Terminate();
        }

        private void InitializeDispatchable()
        {
            _hawk = new Bird();
            _hawk.Name = "Hawk";

            _eagle = new Bird();
            _eagle.Name = "Eagle";

            _eagle.ToHandleEvents = _numberOfEventsToCreate;
        }

        private void DispatchEvents()
        {
            // event fired to the eagle
            FlyEvent fly = new FlyEvent();
            for (int i = 0; i < _numberOfEventsToCreate; i++)
            {
                Dispatcher.GetInstance.Enqueue(_eagle.DISPATCHABLE_ID, fly, Dispatcher.Priority.Normal );
                Dispatcher.GetInstance.Enqueue(_eagle.DISPATCHABLE_ID, fly, Dispatcher.Priority.High);
            }
        }
    }
}