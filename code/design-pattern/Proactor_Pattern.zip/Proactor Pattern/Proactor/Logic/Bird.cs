#region License
/* Copyright (c) 2008 Hamed Ebrahimmalek
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy 
 * of this software and associated documentation files (the "Software"), to 
 * deal in the Software without restriction, including without limitation the 
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or 
 * sell copies of the Software, and to permit persons to whom the Software is 
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in 
 * all copies or substantial portions of the Software. 
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
 * THE SOFTWARE.
 */
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Operational.Interfaces;
using System.Diagnostics;
using EventHandler;
using Events;

namespace Logic
{
    #region Copyright Hamed Ebrahimmalek, 2008
    // Hamed Ebrahimmalek
    //
    // Project              : Proactor
    // Module               : Logic
    // File name            : Bird.cs
    // Revision             : 0.1
    // Creation Date        : 28-04-2008
    // First Author         : Hamed Ebrahimmalek
    //
    // Description          : 
    //
    #endregion

    public class Bird : IDispatchable
    {
        /// <summary>
        /// The name of the bird.
        /// </summary>
        private string _name = String.Empty;

        /// <summary>
        /// The dispatchable of the bird.
        /// </summary>
        private Dispatchable _dispatchable = new Dispatchable();

        /// <summary>
        /// counter of the received events (for the test)
        /// </summary>
        private uint _counter = 0;

        /// <summary>
        /// The number of expected events
        /// </summary>
        private uint _toHandleEvents = 0;

        /// <summary>
        /// This is for a test
        /// </summary>
        public uint ToHandleEvents
        {
            get { return _toHandleEvents; }
            set { _toHandleEvents = value; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public Bird()
        {
            // this will register the Bird
            Dispatcher.GetInstance.Register(this);
        }

        /// <summary>
        /// The name of the Bird
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        /// <summary>
        /// The handle event of the dispatchable
        /// </summary>
        /// <param name="ievent">the event to handle</param>
        public void HandleEvent(IEvent ievent)
        {
            Debug.Assert(ievent != null);

            if (ievent is FlyEvent)
            {
                FlyEvent flyEvent = ievent as FlyEvent;
                Debug.Assert(flyEvent != null);

                // event has arrived
                _counter++;

                if (_counter == _toHandleEvents)
                {
                    // all events have been arrived.
                    // I hold the debugger for you...
                    Debug.Assert(false);
                }
            }
        }

        /// <summary>
        /// The dispatchable id of the Bird
        /// </summary>
        public int DISPATCHABLE_ID
        {
            get { return _dispatchable.DISPATCHABLE_ID; }
            set { _dispatchable.DISPATCHABLE_ID = value; }
        }

    }
}
