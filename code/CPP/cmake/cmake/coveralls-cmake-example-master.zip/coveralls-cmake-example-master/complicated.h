
#ifndef __COMPLICATED_H__
#define __COMPLICATED_H__

int complicated(int a);

#endif // __COMPLICATED_H__
